%% Section E2. Figure E2. Effects of MP Shocks on industrial production based on the ADL and VARs

clear variables
clc
warning('off','all')

%%
% Set Variables
L_fig = 60; % Impulse-Response Horizons
mindelay = 1;
N_B   = 1000; % Number of simulation for confidence bands

% Import data
RRmonth;
[T, ~] = size(data);
L_dy_RR = 24;
L_x_RR  = 36;

% Define variables
initdate=49-36; %49=1970:1 
mp = data(initdate:end,1);
ysa = data(initdate:end,9); % Seasonally-adjusted IP (via Eviews)
dysa = diff(ysa);
dysa = [nan;dysa];

clear data


%% SE & LP Method

% Our Preferred Specification of a Single Equation
[imp_1, imp_1_cb, ~, laglength_ADL, ~] = ir_ADL(dysa, mp, [0:1:20], L_fig, 0, L_fig, 0.9, N_B, mindelay, 0);

% Local Projection
[imp_2, imp_2_cb, ~,laglength_LP, ~, ~] = ir_jorda(ysa, mp, [0:1:20], [0:1:20], 0, 0, L_fig, 0.9, 0);

%% bivariate VAR with L = L_fig + 1

cummp = cumsum(mp); % Cumulated shock series
L_VAR = L_fig+1;

YY = [ysa, cummp]; % VAR system, mp shock comes last

[T, N] = size(YY);
T = T - L_VAR;

lag_matrix = lagmatrix(YY, 1:L_VAR);
Y = YY(L_VAR+1:end,:);
Y=Y(:);
X = [ones(T,1), lag_matrix(L_VAR+1:end,:)];

[phi_hat,~,residual] = regress(Y, kron(eye(N),X));

phi_hat = reshape(phi_hat, N*L_VAR+1, N)';
companion = [phi_hat(:,2:end); eye(N * (L_VAR - 1)), zeros(N*(L_VAR-1), N)];  % Companion Form

% VCV matrix
residual = reshape(residual, T, N)';
omega = zeros(N);
for idx = 1 : T
    omega = omega + residual(:,idx) * residual(:,idx)';
end    
omega = omega / T;
 

C= phi_hat(:,1);
phi = zeros(N, N, L_VAR);
    
for idx = 1:L_VAR
    phi(:, :, idx) = phi_hat(:, N* (idx-1) + 2 : N * idx + 1);
end

psi = zeros(N, N, L_fig+1);
for idx = 1:L_fig+1
    temporary = companion^(idx-1);
    psi(:, :, idx) = temporary(1:N, 1:N);
end
    
omega_root =1/sqrt(omega(2,2))*chol(omega,'lower'); 
for h = 0:L_fig
    psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
end

imp_3 = [squeeze(psi(1,2,:)),  squeeze(psi(2,2,:))];

% Constructing CI with Bootstrapping
ir=[];
parfor b=1:N_B
    
    disp(num2str(b))
    ytemp=[];
    
    % generate new series
    for t=1:T
        if t==1
            ytemp(:,1)=X(1,2:end)';
        else
            index=fix(rand(1,1)*T)+1;
            u = residual(:, index);
            ytemp(:,t)=[C; zeros(N*L_VAR-N,1)]+companion*ytemp(:,t-1)+[u; zeros(N*L_VAR-N,1)];
        end
    end
    
    Ytemp=ytemp(1:N,:)';

    % estimate the new VAR
    
    [cb, phib, omegab, psib, ~, ~, red_res] = var_estimation(Ytemp, L_VAR, L_fig,0);
    
    omega_rootb =  1/sqrt(omegab(2,2))*chol(omegab,'lower');
    for h = 0:L_fig
        psib(:,:,h+1) =  psib(:,:,h+1) * omega_rootb;
    end
    
    ir(b, : , :) = [squeeze(psib(1,2,:)), squeeze(psib(2,2,:))];
    
end

imp_3_cb     = squeeze(quantile(ir, [0.05, 0.16, 0.5, 0.84, 0.95], 1));

%% bivariate VAR with L = 12 (AIC) as in Coibion (2012)

cummp = cumsum(mp); % Cumulated shock series
L_VAR = 12;

YY = [ysa, cummp]; % VAR system, mp shock comes last

[T, N] = size(YY);
T = T - L_VAR;

lag_matrix = lagmatrix(YY, 1:L_VAR);
Y = YY(L_VAR+1:end,:);
Y=Y(:);
X = [ones(T,1), lag_matrix(L_VAR+1:end,:)];

[phi_hat,~,residual] = regress(Y, kron(eye(N),X));

phi_hat = reshape(phi_hat, N*L_VAR+1, N)';
companion = [phi_hat(:,2:end); eye(N * (L_VAR - 1)), zeros(N*(L_VAR-1), N)];  % Companion Form

% VCV matrix
residual = reshape(residual, T, N)';
omega = zeros(N);
for idx = 1 : T
    omega = omega + residual(:,idx) * residual(:,idx)';
end    
omega = omega / T;
 

C= phi_hat(:,1);
phi = zeros(N, N, L_VAR);
    
for idx = 1:L_VAR
    phi(:, :, idx) = phi_hat(:, N* (idx-1) + 2 : N * idx + 1);
end

psi = zeros(N, N, L_fig+1);
for idx = 1:L_fig+1
    temporary = companion^(idx-1);
    psi(:, :, idx) = temporary(1:N, 1:N);
end
    
omega_root =1/sqrt(omega(2,2))*chol(omega,'lower'); 
for h = 0:L_fig
    psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
end

imp_4 = [squeeze(psi(1,2,:)),  squeeze(psi(2,2,:))];

% Constructing CI with Bootstrapping
ir=[];
parfor b=1:N_B
    
    disp(num2str(b))
    ytemp=[];
    
    % generate new series
    for t=1:T
        if t==1
            ytemp(:,1)=X(1,2:end)';
        else
            index=fix(rand(1,1)*T)+1;
            u = residual(:, index);
            ytemp(:,t)=[C; zeros(N*L_VAR-N,1)]+companion*ytemp(:,t-1)+[u; zeros(N*L_VAR-N,1)];
        end
    end
    
    Ytemp=ytemp(1:N,:)';

    % estimate the new VAR
    
    [cb, phib, omegab, psib, ~, ~, red_res] = var_estimation(Ytemp, L_VAR, L_fig,0);
    
    omega_rootb =  1/sqrt(omegab(2,2))*chol(omegab,'lower');
    for h = 0:L_fig
        psib(:,:,h+1) =  psib(:,:,h+1) * omega_rootb;
    end
    
    ir(b, : , :) = [squeeze(psib(1,2,:)), squeeze(psib(2,2,:))];
    
end

imp_4_cb     = squeeze(quantile(ir, [0.05, 0.16, 0.5, 0.84, 0.95], 1));

%% Replication
figure,
subplot(1,2,1)
% For legend
xx = [0:1:L_fig, L_fig:-1:0];
yy = imp_1_cb'; % A = A1, T = 100
yy = [yy(1,:), fliplr(yy(2,:))];
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot(-1, 0, 'r--', 'linewidth', 2), hold on,      % A = A2, T=100, bands
plot(-1, 0, 'r:','linewidth', 1), hold on, % true

% Actual figure
bands = fill(xx, 100*yy, [0.75, 0.75, 0.75]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(0:1:L_fig, 100*imp_1, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(0:1:L_fig, 100*imp_3(:,1), 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(0:1:L_fig, 100*imp_3_cb([1,5], :, 1), 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot(0:1:L_fig, imp_2, 'r--', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0,L_fig])
ylim([-6 5])
set(gca, 'XTick', 0:12:L_fig)
xlabel('Month', 'fontsize', 20)
ylabel('Industrial Production (%)', 'fontsize', 20)
set(gca, 'fontsize', 20)
title(['Single Equation Regression and VAR(' num2str(L_fig+1) ')'], 'fontsize', 20)
legend({['SER'],['SER, 90% band'],['VAR(' num2str(L_fig+1) ')'],['VAR(' num2str(L_fig+1) '), 90% band']}, 'fontsize', 15, 'Location', 'northwest')

subplot(1,2,2)
% For legend
xx = [0:1:L_fig, L_fig:-1:0];
yy = imp_1_cb'; % A = A1, T = 100
yy = [yy(1,:), fliplr(yy(2,:))];
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot(-1, 0, 'r:','linewidth', 1), hold on, % true

% Actual figure
bands = fill(xx, 100*yy, [0.75, 0.75, 0.75]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(0:1:L_fig, 100*imp_1, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(0:1:L_fig, 100*imp_4(:,1), 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(0:1:L_fig, 100*imp_4_cb([1,5], :, 1), 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0,L_fig])
ylim([-6 5])
set(gca, 'XTick', 0:12:L_fig)
xlabel('Month', 'fontsize', 20)
ylabel('Industrial Production (%)', 'fontsize', 20)
set(gca, 'fontsize', 20)
title(['Single Equation Regression and VAR(' num2str(12) ')'], 'fontsize', 20)
legend({['SER'],['SER, 90% band'],['VAR(' num2str(12) ')'],['VAR(' num2str(12) '), 90% band']}, 'fontsize', 15, 'Location', 'northwest')


set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0, 0.75, 1]);

