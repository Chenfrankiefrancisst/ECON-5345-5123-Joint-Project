function [y,x] = dataGen(dgpidx, T, T_burnin)
% dgpidx 1 = hump-shaped, 2 = short run, 3 = long run and true A=1, B=2, 4 = Smets and Wouters

if dgpidx ~= 4   % bivariate
    
    % parameters
    % p and a parametrization; I drop the xi comonent to make it AR(2). This
    % implies that the 'true' B = 2
    rhop1     = 0.26;
    rhop2     = 0.4;
    gy        = 0.5;
    sigmazeta = 1.5;
    
    if dgpidx == 1 % psi_x(L) = hump-shaped
        L_MA = 100;
        
        % psi_(x): Impulse Responses
        x=0:1:L_MA;
        psix = chi2pdf(x, 10);
        psix = psix * 3 / max(psix);   % Maximum response = 3%
        
        % The following matrix would be useful when we simulate a MA(L_MA) process.
        psixt = [fliplr(psix), zeros(1, T - 1)];  % Convolution. We need to flip the MA coefficients.
        lagpsix = lagmatrix(psixt,0:1:T + L_MA - 1)';
        lagpsix(isnan(lagpsix)) = 0;
        sigmax = 1;
        
        % Data generation
        wn = normrnd(0,1,T + T_burnin + L_MA, 2);
        xpart = lagpsix * wn(1:T+L_MA,1) * sigmax;
        
        ppart = zeros(T + T_burnin + 1, 1);
        for idxt = 3:T + T_burnin + 1
            ppart(idxt) = rhop1 * ppart(idxt-1) + rhop2 * ppart(idxt-2) + sigmazeta * wn(idxt,2);
        end
        ppart = cumsum(ppart) + (0:1:T + T_burnin)'*gy;
        
        xpart = xpart(1:T);
        ppart = ppart(end-T+1:end);
        
        % sample (y,x) with size T
        x = wn(end-T-T_burnin+1:end-T_burnin,1);
        y = xpart + ppart;
        x = x(2:end);
        y = diff(y);
        
    elseif dgpidx == 2 % psi_x(L) = 2(1 - rhox L)^(-1)
        sigmax = 2;
        rhox = 0.95;
                
        % Data generation
        wn = normrnd(0,1,T + T_burnin, 2);
        
        xpart = zeros(T + T_burnin, 1);
        ppart = zeros(T + T_burnin, 1);
        for idxt = 3:T + T_burnin
            ppart(idxt) = rhop1 * ppart(idxt-1) + rhop2 * ppart(idxt-2) + sigmazeta * wn(idxt,2);
            xpart(idxt) = rhox * xpart(idxt-1) + sigmax * wn(idxt,1);
        end
        ppart = cumsum(ppart) + (1:1:T + T_burnin)'*gy;
        
        xpart = xpart(end-T+1:end);
        ppart = ppart(end-T+1:end);
        
        % sample (y,x) with size T
        x = wn(end-T+1:end,1);
        y = xpart + ppart;
        x = x(2:end);
        y = diff(y);
        
    elseif dgpidx == 3 % psi_x(L) = (1-L)^(-1)(1 - rhox L)^(-1)
        
        % (1-rhop1L - rhop2L^2) = (1-l1L)(1-l2L)
        l1 = ( rhop1 + sqrt(rhop1^2 + 4 * rhop2) ) / 2;
%         l2 = ( rhop1 - sqrt(rhop1^2 + 4 * rhop2) ) / 2;
        
        sigmax = 1;
        rhox = l1;
       
        % Data generation
        wn = normrnd(0,1,T + T_burnin, 2);
        
        xpart = zeros(T + T_burnin, 1);
        ppart = zeros(T + T_burnin, 1);
        for idxt = 3:T + T_burnin
            ppart(idxt) = rhop1 * ppart(idxt-1) + rhop2 * ppart(idxt-2) + sigmazeta * wn(idxt,2);
            xpart(idxt) = rhox * xpart(idxt-1) + sigmax * wn(idxt,1);
        end
        ppart = cumsum(ppart) + (1:1:T + T_burnin)'*gy;
        xpart = cumsum(xpart);
        
        xpart = xpart(end-T+1:end);
        ppart = ppart(end-T+1:end);
        
        % sample (y,x) with size T
        x = wn(end-T+1:end,1);
        y = xpart + ppart;
        x = x(2:end);
        y = diff(y);
        
    end
    
    
    
else   % Smets and Wouters
    
    [y, x] = MultVarDataGen( T, T_burnin, 1, 5 ); % monetary policy shock -> rgdp
    
    y = diff(y);
    x = x(2:end);
end

end