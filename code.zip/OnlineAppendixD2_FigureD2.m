%% Online Appendix D2. More Monte Carlo Evidences of VAR Specifications
% Figure D2. Performance of various bivariate VARs

clear
clc
close all
warning('off','all')
%% Figure D2. Performance of various bivariate VARs

%1. Data generating process
Tlist = [100];
N_rep = 5000; % Replication

% matlabpool
N_T = length(Tlist);
idxt = 1;
T = Tlist(idxt);
T_burnin = 500; % Burn in periods

% VAR Lag
L_VAR1  = 16;
L_VAR2  = 17;
L_VAR3  = 17;

% psi's: DGP 1
L_MA = 100;
L_fig = 16;

rhop1     = 0.26;
rhop2     = 0.4;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;

% psi_(x): Impulse Responses
x = 0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%
    

% The following matrix would be useful when we simulate a MA(L_MA) process.
psixt = [fliplr(psix), zeros(1, T - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

%%
% 2. Simulation
% parfor

ir1        = zeros(N_rep,1+L_fig,2);    % VAR of (cumx, dy). 1 = from x to y , 2 = from x to x. should be 1 always.
ir2        = zeros(N_rep,1+L_fig,2);    % VAR of (x, y), 1 =from x to y , 2 = from x to x. should be 1 always.
ir3        = zeros(N_rep,1+L_fig,2);    % VAR of (cumx, y) with linear trend, 1 =from x to y , 2 = from x to x. should be 1 always.

parfor idxn = 1:N_rep
    
    disp(num2str(idxn))
    
    % Data generation
    wn = normrnd(0,1,T + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:T+L_MA,1);
    
    ppart = zeros(T + T_burnin + 1, 1);
    apart = zeros(T + T_burnin + 1, 1);
    for idx_dgp = 3:T + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:T+T_burnin)'*gy;
    
    xpart = xpart(1:T);
    ppart = ppart(end-T+1:end);
    apart = apart(end-T+1:end);
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-T-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
    x = x(2:end);
    dy = diff(y);
    cumx = cumsum(x);
    y = y(2:end);
    
    
    % ir1
    [~, ~, omega, psi, ~, ~, ~] = var_estimation([cumx, dy], L_VAR1, L_fig,0);
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir1(idxn,:,:) = [cumsum(squeeze(psi(2,1,:))),  squeeze(psi(1,1,:))];    % impulse response: replication, prediction horizon h, methods, sample size
    
    
    
    
    % ir2
    [~, ~, omega, psi, ~, ~, ~] = var_estimation([x, y], L_VAR2, L_fig,0);
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir2(idxn,:,:) = [squeeze(psi(2,1,:)),  cumsum(squeeze(psi(1,1,:)))]; 
    
    
    % ir3: VAR(cumx, y) with linear trend
    [C, phi, omega, psi, ~, Ttemp, residual, phi_trend] = var_estimation([cumx, y], L_VAR3, L_fig,1);
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir3Temp = [ squeeze(psi(2,1,:)),  squeeze(psi(1,1,:)) ];
    ir3(idxn,:,:) =  ir3Temp;  
  
        
    
end


%% Figure D2. Performance of various bivariate VARs
psix = [psix', ones(size(psix'))];
    
% IR: IR hat
ir1_q     = squeeze(quantile(ir1, [0.025, 0.5, 0.975], 1));
ir2_q     = squeeze(quantile(ir2, [0.025, 0.5, 0.975], 1)); 
ir3_q     = squeeze(quantile(ir3, [0.025, 0.5, 0.975], 1)); 
ir1_m     = squeeze(mean(ir1, 1));
ir2_m     = squeeze(mean(ir2,1));
ir3_m     = squeeze(mean(ir3,1));
 
name_title = {'$(\tilde{x}, \Delta y)^{\prime}: ~ x\rightarrow y$',...
    '$(\tilde{x}, \Delta y)^{\prime}: ~x\rightarrow \tilde{x}$', ...
    '$(x, y)^{\prime}: ~ x\rightarrow y$',...
    '$(x, y)^{\prime}: ~x\rightarrow \tilde{x}$', ...
    '$(\tilde{x}, y)^{\prime} ~w/~ trend: ~ x \rightarrow y$', ...
    '$(\tilde{x}, y)^{\prime} ~w/~ trend: ~ x \rightarrow \tilde{x}$'};

figure,

subplot(3,2,1)
plot(0:1:L_fig, ir1_m(:, 1), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir1_q([1,3],:,1), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-3 5])
set(gca, 'XTick', 0:4:16)
title(name_title(1), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(3,2,2)
plot(0:1:L_fig, ir1_m(:, 2), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir1_q([1,3], :,2), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, ones(L_fig+1,1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-0.5 1.5])
set(gca, 'XTick', 0:4:16)
title(name_title(2), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(3,2,3)
plot(0:1:L_fig, ir2_m(:, 1), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir2_q([1,3], :,1), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-3 5])
set(gca, 'XTick', 0:4:16)
title(name_title(3), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(3,2,4)
plot(0:1:L_fig, ir2_q([1,3], :, 2), 'k:','linewidth',1.5), hold on,
plot(0:1:L_fig, ir2_m(:, 2), 'k-','linewidth',2), hold on,
plot(0:1:L_fig, ones(L_fig+1,1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-0.5 1.5])
set(gca, 'XTick', 0:4:16)
title(name_title(4), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(3,2,5)
plot(0:1:L_fig, ir3_m(:, 1), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir3_q([1,3], :,1), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-3 5])
set(gca, 'XTick', 0:4:16)
title(name_title(5), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(3,2,6)
% for legend
plot(-1, 0, 'k-', 'linewidth', 2); hold on;
plot(-1, 0, 'k:', 'linewidth', 1.5); hold on;
plot(-1, 0, 'r-d', 'linewidth', 2); hold on

plot(0:1:L_fig, ir3_m(:, 2), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir3_q([1,3], :,2), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, ones(L_fig+1,1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-0.5 1.5])
set(gca, 'XTick', 0:4:16)
title(name_title(6), 'interpreter', 'latex', 'fontsize', 20)
legend({'VAR, Mean', 'VAR, 90% band', 'True'}, 'fontsize', 20, 'Orientation','horizontal', 'Location', 'South')
set(gca,'fontsize',20)


