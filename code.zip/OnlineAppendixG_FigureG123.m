%% Section G. Comparison with Local Projection Methods
% Figure G1. Single-Equation ADL & Local Projection Method with Long-Run Effects
% Figure G2-G3. L1 and L2 Total variation of Local projection estimators
clear
clc
close all
warning('off','all')
%% 1. Data generating process
% Set-up
% Initialize
Tlist = [100, 500];
N_rep = 2000;                       % Replication

N_T = length(Tlist);
idxt = 1;

T_burnin = 100; % Burn in periods

% R&R Lag
L_dy_ADL = 2;
L_x_ADL  = 16;
L_max_ADL = max([L_dy_ADL, L_x_ADL]);

% Local Projection Lag
L_dy_DP = 4;
L_x_DP  = 4;
L_max_DP = max([L_dy_DP, L_x_DP]);


% psi's: DGP 1
L_MA = 100;
L_fig = 16;
x = 0:1:L_MA;

% p and a parametrization; I drop the xi comonent to make it AR(2). This
% implies that the 'true' B = 2
rhop1     = 0.26;
rhop2     = 0.4;
rhop3     = 0.00;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;
psix = 0.8.^x;
psix = cumsum(psix);



%% 2. Simulation
% parfor
ir =[];    % 1 = R&R, 2 = Jorda
Ir= [];
for idxt=1:N_T
    
    T=Tlist(idxt);
    
parfor idxn = 1:N_rep
    
    %     if mod(idxn,100) == 0
    %         disp(num2str(idxn))
    %     end
    disp(num2str(idxn))
    % Data generation
    wn = normrnd(0,1,T + T_burnin + L_MA, 3);

    xpart = zeros(T + T_burnin + 1, 1);
    ppart = zeros(T + T_burnin + 1, 1);
    apart = zeros(T + T_burnin + 1, 1);
    
    for idx_dgp = 4:T + T_burnin + 1
        xpart(idx_dgp) = 0.8 * xpart(idx_dgp-1) + wn(idx_dgp,1);
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2)  + rhop3 * ppart(idx_dgp-3)+ sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:T+T_burnin)'*gy;
    xpart = cumsum(xpart);
    
    xpart = xpart(end-T+1:end);
    ppart = ppart(end-T+1:end);
    apart = apart(end-T+1:end);
    
    
    
    % Practical sample with size T
    x = wn(T + T_burnin + 1-T+1:T + T_burnin + 1,1);
    y = xpart + ppart + apart;
    dy = diff(y);
    x = x(2:end);
    y = y(2:end);
    
    %% 1. Single-Equation ADL Model
    
    T_ADL = length(y) - L_max_ADL;
    
    reg_y = dy(L_max_ADL+1:end);
    
    X_dy = lagmatrix(dy, 1:1:L_dy_ADL);
    X_x  = lagmatrix(x, 0:1:L_x_ADL);
    reg_X = [X_dy, X_x];
    reg_X = reg_X(L_max_ADL+1:end,:);
    reg_X = [ones(T_ADL,1), reg_X];
    
    [beta1,~,R1] = regress(reg_y, reg_X);
    
    % Impulse response
    phi1 = beta1(2:L_dy_ADL+1);
    theta1 = beta1(L_dy_ADL+2:end);
    level = 0;
    imp_1 = adltoma(phi1,theta1,L_fig,level);
    
    
    %% 2. Local projection by Jorda
    
    
    T_DP = length(y) - L_max_DP;
    
    imp_3 = zeros(L_fig+1,1);
    
    for h = 0:L_fig
        reg_y = - diff(lagmatrix(y,[0,h+1]),1,2);
        
        X_dy = lagmatrix(dy, h+1:1:h+L_dy_DP);
        X_x  = lagmatrix(x,  h:1:h+L_x_DP);
        reg_X = [X_dy, X_x];
        
        reg_y = reg_y(h+L_max_DP+1:end);
        reg_X = reg_X(h+L_max_DP+1:end,:);
        reg_X = [ones(length(reg_y),1), reg_X];
        
        % Impulse Response
        [beta3h,~,R3h] = regress(reg_y, reg_X);
        imp_3(h+1) = beta3h(1+L_dy_DP+1);
    end
    
    
    ir(idxn,:,:)        = [imp_1, imp_3];

    
end

Ir(:,:,:,idxt) = ir;

end


ir_q = squeeze(quantile(Ir,[0.05, 0.95], 1));
ir_m = squeeze(mean(Ir,1));
%%
%Figure G1,
% Single-Equation ADL Model & Jorda Local Projection Methods with Long-Run
% Effects. Biases.
figure,
xx = [0:1:L_fig, L_fig:-1:0];
yy = ir_q(:, :, 1, 1); % ADL Model, Confidence Interval
yy = [yy(1,:), fliplr(yy(2,:))];

% For Legend
plot(0, 0, 'b-.', 'linewidth', 2), hold on,
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0, 0, 'k-', 'linewidth', 2), hold on, 
plot(0, 0, 'k:', 'linewidth', 1.5), hold on, 
plot(-1, 0, 'r-d', 'linewidth', 2), hold on, 

% Actual figure
bands = fill(xx, yy, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on, % J=J2, T=500, w/ MD assumption bands
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', 2), hold on, % true
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
plot(0:1:L_fig, ir_m(:,2,1), 'k-','linewidth',2), hold on, % Local Projection Method
plot(0:1:L_fig, ir_q(:,:,2,1), 'k:', 'linewidth', 1.5), hold on,      % Local Proejction Method, Confidence Interval
plot(0:1:L_fig, ir_m(:,1,1), 'b-.','linewidth',2), hold on, % ADL Model
xlim([0,L_fig])
% title('Single equation regression vs. Local Prjections', 'fontsize', 15)
set(gca, 'fontsize', 20)
legend({'ADL','ADL, 90% band','LP','LP, 90% band', 'true'},'Orientation', 'horizontal', 'Location', 'South', 'fontsize', 20)


%% SectionG. Figures G2-G3.
% ADL vs. LP: L1 variation and L2 variation. 

clear
clc
%close all
warning('off','all')

%% #1. Set-up
% about simulation
N_rep    = 2000; % Monte Carlo simulation size
L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
I_max    = 4;    % I can be between 0 and I_max for both ADL and LP
JLP_max  = 4;    % J_LP can be between 0 and JLP_max for each h  
J        = 16;   % J_ADL

% matlabpool
N_B = 1;         % Confidence interval is not required.

% about DGP
T = [100, 500];        % Sample size
Tmax = max(T);

T_burnin = 100; % Burn in periods

% contemporaneous response.
L_MA = 100;     % psix(L) ~ MA(L_MA)

% Initialize
impADL = zeros(N_rep, L_fig+1, 2); % ADL: replication, forecasting horizon, T-idx
IADL   = zeros(N_rep, 1, 2);       % selected I due to BIC: replication, h, T-idx

impLP  = zeros(N_rep, L_fig+1, 2); % LP:  replication, forecasting horizon, T-idx
ILP    = zeros(N_rep, L_fig+1, 2); % selected I due to BIC: replication, h, T-idx
JLP    = zeros(N_rep, L_fig+1, 2); % selected J due to BIC: replication, h, T-idx

%% #2. DGP 1
% psi_(x): Impulse Responses

x = 0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%


% The following matrix would be useful when we simulate a MA(L_MA) process.
% T = 500
psixt = [fliplr(psix), zeros(1, Tmax - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:Tmax + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

% p and a parametrization; I drop the xi comonent to make it AR(2). This
% implies that the 'true' I = 2.
rhop1     = 0.26;
rhop2     = 0.4;
rhop3     = 0.00;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;


%% #3. Simulation
parfor idxn = 1:N_rep
    disp(num2str(idxn))
    
    % #3.1. Data generation
    wn = normrnd(0,1,Tmax + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:Tmax+L_MA,1);
    
    ppart = zeros(Tmax + T_burnin + 1, 1);
    apart = zeros(Tmax + T_burnin + 1, 1);
    for idx_dgp = 4:Tmax + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2)  + rhop3 * ppart(idx_dgp-3)+ sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
    
    xpart = xpart(1:Tmax);
    ppart = ppart(end-Tmax+1:end);
    apart = apart(end-Tmax+1:end);
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
%     x = x(2:end);
    dy = diff(y);
%     y = y(2:end);
    
    % temporary    
    impADLTemp = zeros(L_fig+1, 2); % ADL: forecasting horizon, T-idx
    IADLTemp   = zeros(1, 2);       % selected I due to BIC: h, T-idx
    
    impLPTemp  = zeros(L_fig+1, 2); % LP:  forecasting horizon, T-idx
    ILPTemp    = zeros(L_fig+1, 2); % selected I due to BIC: h, T-idx
    JLPTemp    = zeros(L_fig+1, 2); % selected J due to BIC: h, T-idx


    
    % #3.2 T = 500 case
    % ADL
    [impADLTemp(:,2), ~, ~, lagLength] = ir_ADL(dy,x(2:end),0:I_max,J,0,L_fig,0.95,N_B,0,0);
    IADLTemp(:,2) = lagLength.I;
    
    % LP
    [impLPTemp(:,2), ~, ~, lagLength] = ir_jorda(y,x,0:I_max,0:JLP_max,0,0,L_fig,0.95,0,0);
    ILPTemp(:,2)    = lagLength.I; % selected I due to BIC: h, T-idx
    JLPTemp(:,2)    = lagLength.J; % selected J due to BIC: h, T-idx

 
        
    % #3.3 T = 100 case
    y = y(1:100);
    x = x(1:100);
    dy = dy(1:99);
    
    % ADL
    [impADLTemp(:,1), ~, ~, lagLength] = ir_ADL(dy,x(2:end),0:I_max,J,0,L_fig,0.95,N_B,0,0);
    IADLTemp(:,1) = lagLength.I;
    
    % LP
    [impLPTemp(:,1), ~, ~, lagLength] = ir_jorda(y,x,0:I_max,0:JLP_max,0,0,L_fig,0.95,0,0);
    ILPTemp(:,1)    = lagLength.I; % selected I due to BIC: h, T-idx
    JLPTemp(:,1)    = lagLength.J; % selected J due to BIC: h, T-idx

    
    % #3.4 assigning the results
    impADL(idxn,:,:)  = impADLTemp;
    IADL(idxn,:,:)    = IADLTemp;
    
    impLP(idxn,:,:)   = impLPTemp;
    ILP(idxn,:,:)     = ILPTemp;
    JLP(idxn,:,:)     = JLPTemp;
    
end



%% #4. Analyzing the results
% true psix and total variations in L1 and L2-norm
psixJ = psix(1:L_fig+1)';
psixJ_tvTemp = abs(diff([0;psixJ]));         % total variation
psixJ_tvL1 = sum(psixJ_tvTemp);
psixJ_tvL2 = sqrt(sum(psixJ_tvTemp.^2));


% Mean
impADL_m    = squeeze(mean(impADL,1));
impLP_m     = squeeze(mean(impLP,1));

% Quantile
impADL_q    = squeeze(quantile(impADL, [0.025, 0.16, 0.5, 0.84, 0.975], 1));
impLP_q     = squeeze(quantile(impLP, [0.025, 0.16, 0.5, 0.84, 0.975], 1));

% Total variation
temp = zeros(size(impADL) + [0,1,0]);
impADL_tvTemp = temp;
impADL_tvTemp(:,2:end,:) = impADL;
impADL_tvTemp = abs(diff(impADL_tvTemp,1,2));
impADL_tvL1 = squeeze(sum(impADL_tvTemp, 2));
impADL_tvL2 = squeeze(sqrt(sum(impADL_tvTemp.^2, 2)));


impLP_tvTemp = temp;
impLP_tvTemp(:,2:end,:)  = impLP;
impLP_tvTemp = abs(diff(impLP_tvTemp,1,2));
impLP_tvL1 = squeeze(sum(impLP_tvTemp, 2));
impLP_tvL2 = squeeze(sqrt(sum(impLP_tvTemp.^2, 2)));

% 
% %% #5. Figure L1: ADL & LP with Long-run Effects
% 
% figure,
% subplot(1,2,1)
% 
% % For Legend
% plot(-1, 0, 'k-', 'linewidth', 2), hold on, 
% bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
% set(bands,'EdgeColor','None'), hold on,
% plot(-1, 0, 'k-.', 'linewidth', 2), hold on, 
% plot(-1, 0, 'k:', 'linewidth', 1), hold on, 
% plot(-1, 0, 'r-d', 'linewidth', 2), hold on, 
% 
% twoplot(0:L_fig, impADL_m(:,1), impADL_q([1,5],:,1), impLP_m(:,1), impLP_q([1,5],:,1), 2, 1);
% plot(0:L_fig, psixJ, 'rd-', 'linewidth', 2)
% plot([0,L_fig], [0,0], 'r:', 'linewidth', 1)
% lgd = legend('SE', 'SE 95% band', 'LP', 'LP 95% band', 'True', 'orientation', 'horizontal', 'location', 'south');
% set(lgd, 'fontsize', 20)
% set(gca, 'fontsize', 20)
% xlim([0,L_fig])
% title('T = 100', 'fontsize', 20)
% 
% subplot(1,2,2)
% 
% % For Legend
% plot(-1, 0, 'k-', 'linewidth', 2), hold on, 
% bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
% set(bands,'EdgeColor','None'), hold on,
% plot(-1, 0, 'k-.', 'linewidth', 2), hold on, 
% plot(-1, 0, 'k:', 'linewidth', 1), hold on, 
% plot(-1, 0, 'r-d', 'linewidth', 2), hold on, 
% 
% twoplot(0:L_fig, impADL_m(:,2), impADL_q([1,5],:,2), impLP_m(:,2), impLP_q([1,5],:,2), 2, 1);
% plot(0:L_fig, psixJ, 'rd-', 'linewidth', 2)
% plot([0,L_fig], [0,0], 'r:', 'linewidth', 1)
% lgd = legend('SE', 'SE 95% band', 'LP', 'LP 95% band', 'True', 'orientation', 'horizontal', 'location', 'south');
% set(lgd, 'fontsize', 20)
% set(gca, 'fontsize', 20)
% xlim([0,L_fig])
% title('T = 500', 'fontsize', 20)

%% #6. Plot G2-G3. L1 and L2 Total variation
M = 40;   % number of bins


% histogram, L1 norm
[freqADL_L1,locationADL_L1] = hist(impADL_tvL1, M);
relFreqADL_L1 = freqADL_L1 ./ repmat(sum(freqADL_L1),M,1) / ((locationADL_L1(2) - locationADL_L1(1)));

[freqLP_L1,locationLP_L1]   = hist(impLP_tvL1, M);
relFreqLP_L1 = freqLP_L1 ./ repmat(sum(freqLP_L1),M,1) / ((locationLP_L1(2) - locationLP_L1(1)));

figure,
subplot(1,2,1), 
plot(locationADL_L1, relFreqADL_L1(:,1), 'k-', ...
    locationLP_L1, relFreqLP_L1(:,1), 'k-.', 'linewidth', 2), hold on,
plot([psixJ_tvL1, psixJ_tvL1], [0, 0.35], 'r-', 'linewidth', 2)
lgd = legend('ADL', 'LP', 'True', 'orientation', 'vertical', 'location', 'northeast');
set(lgd, 'fontsize', 20)
set(gca, 'fontsize', 20)
title('Total Variation, L1, T = 100', 'fontsize', 20)

subplot(1,2,2)
plot(locationADL_L1, relFreqADL_L1(:,2), 'k-', ...
    locationLP_L1, relFreqLP_L1(:,2), 'k-.', 'linewidth', 2), hold on,
plot([psixJ_tvL1, psixJ_tvL1], [0, 0.8], 'r-', 'linewidth', 2)
lgd = legend('ADL', 'LP', 'True', 'orientation', 'vertical', 'location', 'northeast');
set(lgd, 'fontsize', 20)
set(gca, 'fontsize', 20)
title('Total Variation, L1, T = 500', 'fontsize', 20)





% histogram, L2 norm
[freqADL_L2,locationADL_L2] = hist(impADL_tvL2, M);
relFreqADL_L2 = freqADL_L2 ./ repmat(sum(freqADL_L2),M,1) / ((locationADL_L2(2) - locationADL_L2(1)));

[freqLP_L2,locationLP_L2]   = hist(impLP_tvL2, M);
relFreqLP_L2 = freqLP_L2 ./ repmat(sum(freqLP_L2),M,1) / ((locationLP_L2(2) - locationLP_L2(1)));

figure,
subplot(1,2,1), 
plot(locationADL_L2, relFreqADL_L2(:,1), 'k-', ...
    locationLP_L2, relFreqLP_L2(:,1), 'k-.', 'linewidth', 2), hold on,
plot([psixJ_tvL2, psixJ_tvL2], [0, 1.4], 'r-', 'linewidth', 2)
lgd = legend('ADL', 'LP', 'True', 'orientation', 'vertical', 'location', 'northeast');
set(lgd, 'fontsize', 20)
set(gca, 'fontsize', 20)
title('Total Variation, L2, T = 100', 'fontsize', 20)

subplot(1,2,2)
plot(locationADL_L2, relFreqADL_L2(:,2), 'k-', ...
    locationLP_L2, relFreqLP_L2(:,2), 'k-.', 'linewidth', 2), hold on,
plot([psixJ_tvL2, psixJ_tvL2], [0, 3.5], 'r-', 'linewidth', 2)
lgd = legend('ADL', 'LP', 'True', 'orientation', 'vertical', 'location', 'northeast');
set(lgd, 'fontsize', 20)
set(gca, 'fontsize', 20)
title('Total Variation, L2, T = 500', 'fontsize', 20)


