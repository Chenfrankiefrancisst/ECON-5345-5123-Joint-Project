%% Online Appendix E3 and E4. Contemporaneous Restriction

clear
clc
close all
warning('off','all')

%% Online Appendix E3. Theory 
% #1. Set-up
% about simulation
N_rep    = 5000; % Monte Carlo simulation size
L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
B_max    = 6;    % I can be between 0 and I_max
A1       = 8;
A2       = 16;
% matlabpool
N_B = 1;
% about DGP
T = [100, 500];        % Sample size
Tmax = max(T);
T_burnin = 500; % Burn in periods

% contemporaneous response.
L_MA = 100;     % psix(L) ~ MA(L_MA)

% Initialize
imp_MD = zeros(N_rep, L_fig+1, 2); % replication, forecasting horizon, T-idx

%% #2. DGP
% psi_(x): Impulse Responses
load sw_model_results
psix = oo_.irfs.y_em; % Response of GDP to one s.d. contractionary MP shock
psix = 3 / min(psix) * psix; % Adjust scales to make the response positive and the peak is three.

x = 0:1:L_MA;

psix2 = chi2pdf(x, 10);
psix2 = psix2 * 3 / max(psix2);   % Maximum response = 3%
    
psix = (psix+psix2)/2;

% The following matrix would be useful when we simulate a MA(L_MA) process.
% T = 500
psixt = [fliplr(psix), zeros(1, T(2) - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T(2) + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

% p and a parametrization; I drop the xi comonent to make it AR(2). This
% implies that the 'true' I = 1.
rhop1     = 0.26;
rhop2     = 0.16;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 2;
sigmaxi   = 0;
trueI = 2;

%% #3. Simulation
parfor idxn = 1:N_rep
    disp(num2str(idxn))
    
    % #3.1. Data generation
    wn = normrnd(0,1,Tmax + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:Tmax+L_MA,1);
    
    ppart = zeros(Tmax + T_burnin + 1, 1);
    apart = zeros(Tmax + T_burnin + 1, 1);
    for idx_dgp = 3:Tmax + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
    
    xpart = xpart(1:Tmax);
    ppart = ppart(end-Tmax+1:end);
    apart = apart(end-Tmax+1:end);
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
    x = x(2:end);
    y = diff(y);
    
    % temporary
    imp_MD_temp = zeros(L_fig+1,2);
 
    % imp_MD
    imp_MD_temp(:,2) = ir_ADL(y,x,trueI,A2,0,L_fig,0.95,1,1,0);  % I = 2, J = J2, w/ Min delay assumption
    
    
    % T = 100 case
    y = y(1:99);
    x = x(1:99);
    
    % imp_MD
    imp_MD_temp(:,1) = ir_ADL(y,x,trueI,A2,0,L_fig,0.95,1,1,0);  % I = 1, J = J2, w/ Min delay assumption
    
    
    
    % assigning the results
    imp_MD(idxn,:,:) = imp_MD_temp; % replication, forecasting horizon, T-idx
   
end



%% #4. Analyzing the results
psixJ = psix(1:L_fig+1);

% Mean
imp_MD_m = squeeze(mean(imp_MD,1));

% Quantile
imp_MD_q = squeeze(quantile(imp_MD, [0.05, 0.16, 0.5, 0.84, 0.95], 1));


%% #5. PLOT

%Figure E3,
% Minimum delay assumption
figure,
xx = [0:1:L_fig, L_fig:-1:0];
yymd = imp_MD_q([1,5], :, 2); % A = A2, T = 500
yymd = [yymd(1,:), fliplr(yymd(2,:))];

% For Legend
plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, w/ MD mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, w/ MD bands
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=500, w/ MD mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A2, T=500, w/ MD bands
plot(-1, 0, 'rd-', 'linewidth', 2), hold on, % true
plot(-1, 0, 'g-+', 'linewidth', 2)

% Actual figure
bands = fill(xx, yymd, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A2, T=500, w/ MD assumption bands
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
plot(0:1:L_fig, imp_MD_m(:,2), 'b-.', 'linewidth', 2), hold on,      % A = A2, T=500, w/ MD assumption mean
plot(0:1:L_fig, imp_MD_m(:,1), 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, w/ MD mean
plot(0:1:L_fig, imp_MD_q([1,5],:,1), 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, w/ MD bands
plot(0:1:L_fig, psixJ, 'rd-', 'linewidth', 2), hold on, % true
xlim([0,L_fig])
ylim([-4,4])


dpsix = diff([0,psix]);

betaInv = zeros(1,L_MA+1);

betaInv(1) = 1;
betaInv(2) = rhop1;
for h = 2:L_MA
betaInv(h+1) = rhop1 * betaInv(h) + rhop2 * betaInv(h-1);
end

dpsixr = dpsix - psix(1) * betaInv;

psixr = cumsum(dpsixr);
plot(0:1:L_fig, psixr(1:L_fig+1), 'g-+', 'linewidth', 2)


% title('Contempraneous Restriction, T = 100 and 500', 'fontsize', 15)
set(gca, 'fontsize', 20)
legend({'T=100','T=100, 90% band','T=500','T=500, 90% band', 'True', 'True(r)'},'Orientation', 'horizontal', 'Location', 'South', 'fontsize', 20)

%%  Online Appendix E4. Application
clear variables
clc
warning('off','all')

% Set Variables
L_fig = 48; % Impulse-Response Horizons
N_B   = 2000; % Number of simulation for confidence bands

% A. Romer and Romer(2004) with Monthly Data
% Import data
RRmonth;
[T, ~] = size(data);
L_dy_RR = 24;
L_x_RR  = 36;

% Define variables
initdate=49-36; %49=1970:1
mp = data(initdate:end,1);
dy = data(initdate:end,2);
month = data(initdate:end,6);
y = data(initdate:end,7);
ysa = data(initdate:end,9); % Seasonally-adjusted IP (via Eviews)
dysa = diff(ysa);
dysa = [nan;dysa];

dummy_volcker=zeros(T,1);
dummy_volcker(166:216,1)=1;
dummy_outlier=zeros(T,1);
dummy_outlier(172,1)=1; %172=1980:4
dummy_outlier=dummy_outlier(initdate:end);
interaction_outlier=mp.*dummy_outlier;

dummy_volcker=dummy_volcker(initdate:end);
interaction_volcker = mp.*dummy_volcker;

dummy_outlier_RR0 = lagmatrix(dummy_outlier, 0:1:L_x_RR);
dummy_outlier_RR1 = lagmatrix(dummy_outlier, 1:1:L_x_RR);
dummy_outlier_ours = lagmatrix(dummy_outlier, 0:1:L_fig);
interactionmat_outlier_RR0=lagmatrix(interaction_outlier,0:1:L_x_RR);
interactionmat_outlier_RR1=lagmatrix(interaction_outlier,1:1:L_x_RR);
interactionmat_outlier_ours=lagmatrix(interaction_outlier, 0:1:L_fig);

% Volcker Period Dummy Lag matrix
dummymat_volcker_RR1 = lagmatrix(dummy_volcker,  1:1:L_x_RR);
dummymat_volcker_RR0 = lagmatrix(dummy_volcker,  0:1:L_x_RR);
dummymat_volcker_ours = lagmatrix(dummy_volcker,  0:1:L_fig);
interactionmat_volcker_ours = lagmatrix(interaction_volcker, 0:1:L_fig);
interactionmat_volcker_RR0 = lagmatrix(interaction_volcker, 0:1:L_x_RR);
interactionmat_volcker_RR1 = lagmatrix(interaction_volcker, 1:1:L_x_RR);

Month = dummyvar(month);
dummy_month = Month(:,2:end); % Dummy variable of months

clear data


%% Figure E4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% for Figure E4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Romer and Romer (2004); Replication, Solid Line
[imp_1, imp_1_cb, ~, ~, ~] = ir_ADL(dysa, mp, L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 1);

% Our Preferred Specification, Red Solid Line with Circles
[imp_2, imp_2_cb, ~, laglength_ADL, ~] = ir_ADL(dysa, mp, [0:1:20], L_fig, 0, L_fig, 0.9, N_B, 0, 0);

% Romer and Romer (2004) w/o Contemporaneous Restrictions
[imp_3, imp_3_cb, ~, ~, ~] = ir_ADL(dysa, mp, L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 0);


figure,
% For Legend,
xx = [0:1:L_fig, L_fig:-1:0];
yy11 = imp_2_cb';
yy11 = [yy11(1,:), fliplr(yy11(2,:))];
plot(-1, 0, 'k-', 'linewidth', 2), hold on,
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on, 
plot(-1, 0, 'b-d', 'linewidth', 2), hold on,
plot(-1, 0, 'k-.', 'linewidth', 1.5), hold on, 
plot(-1, 0, 'r-o', 'linewidth', 2), hold on, 
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);

% Actual Figure
set(bands,'EdgeColor','None'), hold on, % J=J1, T=500, bands
bands = fill(xx, 100*yy11, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0:1:L_fig, 100*imp_1, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_1_cb, 'k:', 'linewidth', 1.5), hold on,
plot(0:1:L_fig, 100*imp_3, 'b-d', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_3_cb, 'k-.', 'linewidth', 1.5), hold on,
plot(0:1:L_fig, 100*imp_2, 'r-o', 'linewidth', 2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
xlim([0 L_fig]),
ylim(100*[-0.08 0.04])
set(gca, 'fontsize', 20)
legend({'R&R', '90% CI', 'R&R w/o rest.', '90% CI', 'Selected', '90% CI'}, 'Fontsize', 20, 'Location','south','Orientation','horizontal')


%% Online Appendix E4. Applications, Figure E5: Controlling for Outliers

% Controlling for Early Volcker Period
% Romer and Romer (2004); Replication
% Note that the data is already seasonally adjusted. 
[imp_1, imp_1_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummy_outlier_RR1, interactionmat_outlier_RR1], L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 1);

% Romer and Romer (2004) Baseline Specification, but w/o no contemponareous response assumption
% Note that the data is already seasonally adjusted. 
[imp_2, imp_2_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummy_outlier_RR0, interactionmat_outlier_RR0], L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 0);

% Our Preferred Specification
[imp_11, imp_11_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummymat_volcker_ours, interactionmat_volcker_ours], [0:1:20], L_fig, 0, L_fig, 0.9, N_B, 0, 0);


% Controlling for Early Volcker Period
% Romer and Romer (2004); Replication
% Note that the data is already seasonally adjusted. 
[imp_4, imp_4_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummymat_volcker_RR1, interactionmat_volcker_RR1], L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 1);

% Romer and Romer (2004) Baseline Specification, but w/o no contemponareous response assumption
% Note that the data is already seasonally adjusted. 
[imp_5, imp_5_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummymat_volcker_RR0, interactionmat_volcker_RR0], L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 0);

% Our Preferred Specification
[imp_22, imp_22_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummymat_volcker_ours, interactionmat_volcker_ours], [0:1:20], L_fig, 0, L_fig, 0.9, N_B, 0, 0);


%% Figure E5
figure,
subplot(1,2,1)
% For Legend,
xx = [0:1:L_fig, L_fig:-1:0];
yy11 = imp_11_cb';
yy11 = [yy11(1,:), fliplr(yy11(2,:))];
plot(0, 0, 'k-', 'linewidth', 2), hold on,
plot(0, 0, 'k:', 'linewidth', 1.5), hold on, 
plot(-1, 0, 'r-o', 'linewidth', 2), hold on, 
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);
plot(0, 0, 'b-.', 'linewidth', 2), hold on

% Actual Figure
set(bands,'EdgeColor','None'), hold on,
bands = fill(xx, 100*yy11, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0:1:L_fig, 100*imp_1, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_1_cb, 'k:', 'linewidth', 1.5), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
plot(0:1:L_fig, 100*imp_11, 'r-o', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_2, 'b-.', 'linewidth', 2), hold on,
axis([0 L_fig -100*0.07 100*0.04])
set(gca,'fontsize', 20)
legend({'R&R','90% CI', 'Selected', '90% CI', 'R&R w/o rest.'}, 'Fontsize', 20, 'Location','south','Orientation','horizontal')
title('1980:M4 ', 'fontsize', 20)

subplot(1,2,2)
xx = [0:1:L_fig, L_fig:-1:0];
yy22 = imp_22_cb';
yy22 = [yy22(1,:), fliplr(yy22(2,:))];

% For Legend
plot(0, 0, 'k-', 'linewidth', 2), hold on,
plot(0, 0, 'k:', 'linewidth', 1.5), hold on,
plot(-1, 0, 'r-o', 'linewidth', 2), hold on,
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);
plot(0, 0, 'b-.', 'linewidth', 2), hold on,

% Actual Figures
set(bands,'EdgeColor','None'), hold on,
bands = fill(xx, 100*yy22, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0:1:L_fig, 100*imp_4, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_4_cb, 'k:', 'linewidth', 1.5), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
plot(0:1:L_fig, 100*imp_22, 'r-o', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_5, 'b-.', 'linewidth', 2), hold on,
axis([0 L_fig -100*0.07 100*0.04])
set(gca,'fontsize', 20)
% legend({'R&R','90% CI', 'Selected', '90% CI', 'R&R w/o rest.'}, 'Fontsize', 17, 'Location','south','Orientation','horizontal')
title('Early Volcker Period', 'fontsize', 20)

