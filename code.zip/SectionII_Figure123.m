    %% Section 2 Figures
% Figure 1. Population Impulse Responses under the assumed DGPs
% Figure 2. A and consistency 
% Figure 3. B and MSE
% A and consistency : T = 100 and 500 / A = 8 and 12.
% B and MSE         : T = 100, B varies from 0 to B_max. Information
%                     criterions are also studied.

clear
clc
close all 
warning('off','all')

%% #1. Set-up
% about simulation
N_rep    = 5000; % Monte Carlo simulation size
L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
A_max    = 16;   % A can be between 0 and A_max
B_max    = 16;   % B can be between 0 and B_max
A1       = 8;
A2       = 16;

N_B = 1; %1000;
% N_B_IMSE = 2000;

% about DGP
T = [100, 500];        % Sample size
Tmax = max(T);
Tmin = min(T);

T_burnin = 500; % Burn in periods

% contemporaneous response.
L_MA = 100;     % psix(L) ~ MA(L_MA)

% Initialize
imp_A = zeros(N_rep, L_fig+1, 4, 2); % replication, forecasting horizon, A-idx, T-idx
imp_B = zeros(N_rep, L_fig+1, B_max + 6, 2); % replication, forecasting horizon, I-idx including 0, BIC, HQIC, AIC, T-idx
ABA_IC = zeros(N_rep, 2, 2); % selected A by IC: replication, BIC/AIC, T-idx, when both A and B are chosen by IC
ABB_IC = zeros(N_rep, 2, 2); % selected B by IC: replication, BIC/AIC, T-idx, when both A and B are chosen by IC
B_IC   = zeros(N_rep, 3, 2); % selected B by IC: replication, BIC/HQIC/AIC, T-idx when A is fixed to be A2

%% #2. DGP
% psi_(x): Impulse Responses
x=0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%


% The following matrix would be useful when we simulate a MA(L_MA) process.
% T = 500
psixt = [fliplr(psix), zeros(1, T(2) - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T(2) + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

% p and a parametrization; I drop the xi comonent to make it AR(2). This
% implies that the 'true' B = 2
rhop1     = 0.26;
rhop2     = 0.4;
rhop3     = 0.00;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;
trueB = 2;

psie = [0;sigmazeta];

for h = 2:L_fig+1
    psie(h+1) = rhop1 * psie(h) + rhop2 * psie(h-1);
end
psie = psie(2:end);
psie = cumsum(psie)';

%% #3. Simulation

% rng(1234) : set a seed number for the random number generator for replicability
tic
parfor idxn = 1:N_rep
    disp(num2str(idxn))
    
    % #3.1. Data generation
    wn = normrnd(0,1,Tmax + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:Tmax+L_MA,1);
    
    ppart = zeros(Tmax + T_burnin + 1, 1);
    apart = zeros(Tmax + T_burnin + 1, 1);
    for idx_dgp = 4:Tmax + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2)  + rhop3 * ppart(idx_dgp-3)+ sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
    
    xpart = xpart(1:Tmax);
    ppart = ppart(end-Tmax+1:end);
    apart = apart(end-Tmax+1:end);
   
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
    x = x(2:end);
    y = diff(y);
    
    % temporary
    imp_A_temp = zeros(L_fig+1,4,2);
    imp_B_temp = zeros(L_fig+1,B_max+4,2);
    ABA_IC_temp = zeros(2,2);
    ABB_IC_temp = zeros(2,2);
    B_IC_temp = zeros(3,2);
        
    
    % #3.2 T = Tmax case
    % imp_A
    imp_A_temp(:,1,2) = ir_ADL(y,x,trueB,A1,0,L_fig,0.95,N_B,0,0); % B = 2, A = A1
    imp_A_temp(:,2,2) = ir_ADL(y,x,trueB,A2,0,L_fig,0.95,N_B,0,0); % B = 2, A = A2
    [imp_A_temp(:,3,2),~,~,ABlengthB2] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,N_B,0,0); % A and B via the BIC 
    ABA_IC_temp(1,2) = ABlengthB2.J;
    ABB_IC_temp(1,2) = ABlengthB2.I;
    [imp_A_temp(:,4,2),~,~,ABlengthA2] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,N_B,0,2); % A and B via the AIC
    ABA_IC_temp(2,2) = ABlengthA2.J;
    ABB_IC_temp(2,2) = ABlengthA2.I;
    
    % imp_B
    % Fixed I from 0 to I_max
    for Iidx = 0:1:B_max
        imp_B_temp(:,Iidx+1,2) = ir_ADL(y,x,Iidx,A2,0,L_fig,0.95,N_B,0,0); % varying B, A = A2
    end
    % Information criterion
    [imp_B_temp(:,B_max+2,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,0); % B = BIC, A = A2
    B_IC_temp(1,2) = llength.I;
    [imp_B_temp(:,B_max+3,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,1); % B = HQIC, A = A2
    B_IC_temp(2,2) = llength.I;
    [imp_B_temp(:,B_max+4,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,2); % B = AIC, A = A2
    B_IC_temp(3,2) = llength.I;
    imp_B_temp(:,B_max+5,2) = imp_A_temp(:,3,2); % A and B via the BIC
    imp_B_temp(:,B_max+6,2) = imp_A_temp(:,4,2); % A and B via the BIC


    
    % #3.3 T = Tmin case
    y = y(1:Tmin-1);
    x = x(1:Tmin-1);

    % imp_A
    imp_A_temp(:,1,1) = ir_ADL(y,x,trueB,A1,0,L_fig,0.95,N_B,0,0); % B = 2, A = A1
    imp_A_temp(:,2,1) = ir_ADL(y,x,trueB,A2,0,L_fig,0.95,N_B,0,0); % B = 2, A = A2

    [imp_A_temp(:,3,1),~,~,ABlengthB1] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,N_B,0,0); % A and B via the BIC
    ABA_IC_temp(1,1) = ABlengthB1.J;
    ABB_IC_temp(1,1) = ABlengthB1.I;
    [imp_A_temp(:,4,1),~,~,ABlengthA1] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,N_B,0,2); % A and B via the AIC
    ABA_IC_temp(2,1) = ABlengthA1.J;
    ABB_IC_temp(2,1) = ABlengthA1.I;
    
    % imp_B
    % Fixed I from 0 to B_max
    for Iidx = 0:1:B_max
        imp_B_temp(:,Iidx+1,1) = ir_ADL(y,x,Iidx,A2,0,L_fig,0.95,N_B,0,0); % varying B, A = A2
    end
    
    
    % Information criterion
    [imp_B_temp(:,B_max+2,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,0); % B = BIC, A = A2
    B_IC_temp(1,1) = llength.I;
    [imp_B_temp(:,B_max+3,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,1); % B = HQIC, A = A2
    B_IC_temp(2,1) = llength.I;
    [imp_B_temp(:,B_max+4,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,2); % B = AIC, A = A2
    B_IC_temp(3,1) = llength.I;
    imp_B_temp(:,B_max+5,1) = imp_A_temp(:,3,1); % A and B via the BIC
    imp_B_temp(:,B_max+6,1) = imp_A_temp(:,4,1); % A and B via the AIC

    
    
    % #3.4 assigning the results
    imp_A(idxn,:,:,:) = imp_A_temp; % replication, forecasting horizon, A-idx, T-idx
    imp_B(idxn,:,:,:) = imp_B_temp; % replication, forecasting horizon, B-idx including 0, BIC, HQIC, AIC, T-idx
    ABA_IC(idxn,:,:) = ABA_IC_temp; % selected A due to IC: replication, BIC/AIC, T-idx, when both A and B are chosen via IC
    ABB_IC(idxn,:,:) = ABB_IC_temp; % selected B due to IC: replication, BIC/AIC, T-idx, when both A and B are chosen via IC
    B_IC(idxn,:,:) = B_IC_temp;     % selected B due to IC: replication, BIC/HQIC/AIC, T-idx, when A is fixed to be A2
 
    
end
toc
save('simulation_sectionII.mat'); %, 'imp_A', 'imp_B', 'ABA_IC', 'ABB_IC','B_IC');

%% #4. Analyzing the results
psixA = psix(1:L_fig+1);

% Mean
imp_A_m = squeeze(mean(imp_A,1));
imp_B_m = squeeze(mean(imp_B,1));

% Quantile
imp_A_q = squeeze(quantile(imp_A, [0.05, 0.16, 0.5, 0.84, 0.95], 1));
imp_B_q = squeeze(quantile(imp_B, [0.05, 0.16, 0.5, 0.84, 0.95], 1));

% MSE = BIAS^2 + SD^2
dimp = imp_B - repmat(psixA, [N_rep,1,B_max+6,2]);
mse = sum(dimp.^2,1)/N_rep;
mse = squeeze((mse));
% Bias
bias2 = (imp_B_m - repmat(psixA', [1,B_max+6,2])).^2;
% SD
var   = squeeze(std(imp_B,0,1)).^2;

% True B=2
% "R" stands for "Relative"
% Rmse records Relative MSE to the true one
% Rbias2 records Relative Bias.^2 to the true one
% Rvar records Relatvie Variance to the true one
Rmse=[];
Rbias2=[];
Rvar=[];
for ii=1:B_max+6
    Rmse(:,ii,:) = mse(:,ii,:)./mse(:,trueB+1,:);
    Rbias2(:,ii,:)=bias2(:,ii,:)./bias2(:,trueB+1,:);
    Rvar(:,ii,:)=var(:,ii,:)./var(:,trueB+1,:);
end



%% #5. PLOT

% % Figure 1. Population Impulse Response
% figure,
% plot(0:1:L_fig, psix(1:L_fig+1), 'k-', 'linewidth', 2)
% xlabel('$c$', 'interpreter', 'latex', 'fontsize', 20)
% ylabel('$\psi_{x,c}$', 'interpreter', 'latex', 'fontsize', 20)
% set(gca, 'fontsize', 20)
% ylim([0,4])
% xlim([0,L_fig])


lw = 2;
fs = 20;
% Population
L_fig= 16;

psixPopulation = zeros(L_fig+1, 4);

for dgpidx = 1:4
    psixPopulation(:,dgpidx) = populationIRF(dgpidx, L_fig);
end

% Figure 1. Population Impulse Response
figure,
plot(0:1:L_fig, psixPopulation(:,1), 'k-', 'linewidth', lw), hold on
plot(0:1:L_fig, psixPopulation(:,2), 'k:', 'linewidth', lw), hold on
plot(0:1:L_fig, psixPopulation(:,3), 'k-.', 'linewidth', lw), hold on
plot(0:1:L_fig, psixPopulation(:,4), 'k-d', 'linewidth', lw), hold on
lgd = legend('DGP1', 'DGP2', 'DGP3', 'Smets-Wouters', 'autoupdate', 'off');
set(lgd, 'fontsize', fs, 'location', 'best')
xlabel('$c$', 'interpreter', 'latex', 'fontsize', fs)
ylabel('$\psi_{x,c}$', 'interpreter', 'latex', 'fontsize', fs)
set(gca, 'fontsize', fs)
plot([0 L_fig], [0 0], 'r-', 'linewidth', lw / 2), hold on

 
% %% FEVD
% 
% figure,
% plot(0:1:L_MA, psix.^2 ./ ( psix.^2 + psie.^2 )), hold on
% plot(0:1:L_MA, (2 * 0.95.^(0:L_MA)).^2  ./ ( (2 * 0.95.^(0:L_MA)).^2  + psie.^2 )), hold on
% plot(0:1:L_MA, (2 * 0.5 * cumsum(l1.^(0:L_MA))).^2  ./ ( (2 * 0.5 * cumsum(l1.^(0:L_MA))).^2  + psie.^2 )), hold on
% 
% xlim([0,L_fig])




%%
% Figure 2. Consistency and A.

ms = 10;        % marker size. 
figure,   
% Consistency and A, A = A1 vs. A2, T = 100
subplot(1,2,1)
xx = [0:1:L_fig, L_fig:-1:0];
yy = imp_A_q([1,5], :, 1,1); % A = A1, T = 100
yy = [yy(1,:), fliplr(yy(2,:))];

% For Legend
plot(-1, 0, 'k-', 'linewidth', 2), hold on,       % A = A2, T=100, mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,     % A = A2, T=100, bands
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(-1, 0, 'rd-', 'linewidth', 2, 'markersize', ms), hold on, % true

% Actual figure
bands = fill(xx, yy, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(0:1:L_fig, imp_A_m(:,1,1), 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(0:1:L_fig, imp_A_m(:,2,1), 'k-',  'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(0:1:L_fig, imp_A_q([1,5],:,2,1), 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot(0:1:L_fig, psixA, 'rd-', 'linewidth', 2, 'markersize', ms), hold on, % true
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0,L_fig])
set(gca, 'XTick', 0:4:L_fig)
xlabel('$c$', 'interpreter', 'latex', 'fontsize', 20)
ylabel('$\psi_{x,c}$ and $\hat{\psi}_{x,c}$', 'interpreter', 'latex', 'fontsize', 20)
title('A = C and A < C', 'fontsize', 20)
set(gca, 'fontsize', 20)
legend({['A=16, B=2'],['A=16, B=2, 90% band'],['A=8, B=2'],['A=8, B=2, 90% band'], 'True'}, 'fontsize', 20, 'Location', 'SouthWest')
ylim([-5,8])

% Consistency and A, A and B via BIC, AIC, T = 100
subplot(1,2,2)
yy = imp_A_q([1,5], :, 3,1); % A and B via the BIC, bands
yy = [yy(1,:), fliplr(yy(2,:))];

% For Legend
plot(-1, 0, 'k-', 'linewidth', 2), hold on,     % A and B via the AIC, T=100, mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,   % A and B via the AIC, T=100, bands
plot(-1, 0, 'b-.','linewidth', 2), hold on,     % A and B via the BIC, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on,          % A and B via the BIC, T=100, bands
plot(-1, 0, 'rd-', 'linewidth', 2, 'markersize', ms), hold on, % true

% Actual figure
bands = fill(xx, yy, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on, % A and B via the BIC, bands
plot(0:1:L_fig, imp_A_m(:,3,1), 'b-.', 'linewidth', 2), hold on,          % A and B via the BIC, T=100, mean
plot(0:1:L_fig, imp_A_m(:,4,1), 'k-', 'linewidth', 2), hold on,          % A and B via the AIC, T=100, mean
plot(0:1:L_fig, imp_A_q([1,5],:,4,1), 'k:', 'linewidth', 1.5), hold on,   % A and B via the AIC, T=100, bands
plot(0:1:L_fig, psixA, 'rd-', 'linewidth', 2, 'markersize', ms), hold on, % true
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0,L_fig])
xlabel('$c$', 'interpreter', 'latex', 'fontsize', 20)
ylabel('$\psi_{x,c}$ and $\hat{\psi}_{x,c}$', 'interpreter', 'latex', 'fontsize', 20)
title('Information criteria', 'fontsize', 20)
set(gca, 'XTick', 0:4:L_fig)
legend({['A & B via AIC'],['A & B via AIC, 90% band'],['A & B via BIC'],['A & B via BIC, 90% band'], 'True'}, 'fontsize', 20, 'Location', 'SouthWest')
ylim([-5, 8])
set(gca, 'fontsize', 20)

mean(ABA_IC(:,:,1))
mean(ABB_IC(:,:,1))
%%
% Figure 3. I and Efficiency,
ms = 15;        % marker size. 
figure,
subplot(1,2,1)
% T = 100, MSE
plot(0:1:L_fig, Rmse(:,B_max+2,1), 'r-o', 'linewidth', 2), hold on
plot(0:1:L_fig, Rmse(:,1,1), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, Rmse(:,5,1), 'k:', 'linewidth', 2), hold on
%plot(0:1:L_fig, Rmse(:,7,1), 'k--', 'linewidth', 2), hold on
plot(0:1:L_fig, Rmse(:,9,1), 'k--', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlabel('$c$', 'interpreter', 'latex', 'fontsize', 20)
% xlabel('IRF horizon')
ylabel('Relative MSE')
xlim([0 L_fig])
set(gca, 'XTick', 0:4:L_fig)
legend({ 'B via BIC, A = 16', 'B = 0, A = 16','B = 4, A = 16', 'B = 8, A = 16'}, 'Location', 'Northeast', 'fontsize', 20)
%title('T=100', 'fontsize', 20)
set(gca, 'fontsize', 20)
ylim([0.9, 1.7])

subplot(1,2,2)
% T = 100, MSE
plot(0:1:L_fig, Rmse(:,B_max+2,1), 'r-o', 'linewidth', 2), hold on
plot(0:1:L_fig, Rmse(:,B_max+6,1), 'b-+', 'linewidth', 2), hold on
plot(0:1:L_fig, Rmse(:,B_max+5,1), 'b-.', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlabel('$c$', 'interpreter', 'latex', 'fontsize', 20)
% xlabel('IRF horizon')
ylabel('Relative MSE')
xlim([0 L_fig])
set(gca, 'XTick', 0:4:L_fig)
legend({ 'B via BIC, A = 16', 'A & B via AIC', 'A & B via BIC'}, 'Location', 'Northeast', 'fontsize', 20)
%title('T=100', 'fontsize', 20)
set(gca, 'fontsize', 20)
ylim([0.5, 4.5])

squeeze(mean(B_IC))