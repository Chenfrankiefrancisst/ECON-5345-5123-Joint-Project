function [] = twoplot(x, y1, y1cb, y2, y2cb, lw, holdOnFlag, y1type, y2type, y2cbtype, legendOrderFlag, y3type)
%Plots x vs. y1 with confidence bands y1cb, and x vs. y2 w/ confidence
% bands y2cb.
% y1cb and y2cb should be 2 by length(x) matrices.
% lw = linewidth
% holdOnFlag. If not 1, it ends w/o 'hold on.'
% y1type, y2type, and y2cbtpye: line specification, e.g. 'k-'. y1cb is
% based on 'fill' command.
% If legendOrderFlag == 2, y2 and y2cb come first in the legend.

% Written by Byoungchan Lee, 05/16/2018

if nargin < 7
    holdOnFlag = 1;
end

if nargin < 8
    y1type = 'k-';
end

if nargin < 9
    y2type = 'k-.';
end

if nargin < 10
    y2cbtype = 'k:';
end

if nargin < 11
    legendOrderFlag = 1;
end

if nargin < 12
    y3type = [];
end

x = x(:)';
xx = [x, fliplr(x)];


% For legend
if legendOrderFlag == 2
    plot(x(1)-1, y2(1), y2type, 'linewidth', lw), hold on,
    plot(x(1)-1, y2(1), y2cbtype, 'linewidth', lw/2), hold on,
    plot(x(1)-1, y1(1), y1type, 'linewidth', lw), hold on,
    fill([x(1)-2,x(1)-1], [y1(1), y1(1)], [.7,.7,.7], 'Edgecolor', 'None')
    if ~isempty(y3type)
        plot(x(1)-1, y1(1), y3type, 'linewidth', lw), hold on,
    end
else
    plot(x(1)-1, y1(1), y1type, 'linewidth', lw), hold on,
    fill([x(1)-2,x(1)-1], [y1(1), y1(1)], [.7,.7,.7], 'Edgecolor', 'None'), hold on,
    plot(x(1)-1, y2(1), y2type, 'linewidth', lw), hold on,
    plot(x(1)-1, y2(1), y2cbtype, 'linewidth', lw/2)
end
% Actual plot
cb1 = fill(xx, [y1cb(1,:), fliplr(y1cb(2,:))], [.7, .7, .7]);
set(cb1,'EdgeColor','None'), hold on,

plot(x, y1, y1type, 'linewidth', lw), hold on,
plot(x, y2, y2type, 'linewidth', lw), hold on,
plot(x, y2cb, y2cbtype, 'linewidth', lw/(4/3))

xlim([min(x), max(x)])

if holdOnFlag == 1
    hold on
end


end