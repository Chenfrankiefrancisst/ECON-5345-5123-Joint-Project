%% Tables C1-C4. More Monte Carlo Simulations based on various DGPs.

clear
clc
close all
warning('off','all')


%% #1. Set-up
% about simulation
for dgpidx = 1:4; % 1 = hump-shaped, 2 = short-run effects, 3 = long-run effects and true A=1, B=2, 4 = Smets and Wouters output and monetary policy shocks
    
    N_rep    = 5000; % Monte Carlo simulation size
    L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
    A_max    = 16;   % A can be between 0 and A_max
    B_max    = 16;   % B can be between 0 and B_max
    % A1       = 8;
    % A2       = 16;
    N_B = 2000;
    
    % about DGP
    T = 100;        % Sample size
    % Tmax = max(T);
    % Tmin = min(T);
    
    T_burnin = 500; % Burn in periods
    
    % Initialize
    imp_AB      = zeros(N_rep, L_fig+1, A_max+1, B_max+1); % replication, ir horizon, A-idx, B-idx
    imp_IC_AB   = zeros(N_rep, L_fig+1, 2); % replication, ir horizon, A and B are jointly chosen by IC (BIC, AIC)
    imp_IC_A    = zeros(N_rep, L_fig+1, 2); % replication, ir horizon, A is chosen by IC (BIC, AIC) given B = 2 (true unless dgp = Smets and Wouters)
    imp_IC_B    = zeros(N_rep, L_fig+1, 2); % replication, ir horizon, B is chosen by IC (BIC, AIC) given A = 16
    
    IC_ABA      = zeros(N_rep, 2); % selected A by IC: replication, BIC/AIC, when both A and B are chosen by IC
    IC_ABB      = zeros(N_rep, 2); % selected B by IC: replication, BIC/AIC, when both A and B are chosen by IC
    IC_A        = zeros(N_rep, 2); % selected A by IC: replication, BIC/AIC, when only A is chosen by IC given B = 2
    IC_B        = zeros(N_rep, 2); % selected B by IC: replication, BIC/AIC, when only B is chosen by IC given A = 16
    
    %% #2. Simulation
    
    % rng(1234) : set a seed number for the random number generator for replicability
    tic
    parfor idxn = 1:N_rep
        disp(num2str(idxn))
        
        % data generation
        [y,x] = dataGen(dgpidx, T, T_burnin);
        
        % temporary results for each parfor iteration
        imp_AB_temp    = zeros(L_fig+1, A_max+1, B_max+1);
        imp_IC_AB_temp = zeros(L_fig+1, 2);
        imp_IC_A_temp  = zeros(L_fig+1, 2);
        imp_IC_B_temp  = zeros(L_fig+1, 2);
        
        IC_ABA_temp    = zeros(1,2);
        IC_ABB_temp    = zeros(1,2);
        IC_A_temp      = zeros(1,2);
        IC_B_temp      = zeros(1,2);
        
        % 1) for all pairs of (A,B)
        for A = 0:A_max
            for B = 0:B_max
                imp_AB_temp(:, A+1, B+1) = ir_ADL_IC(y,x,B,A,0,L_fig,0.95,2000,0,0,0,0,1);
            end
        end
        
        % 2) Information criterion (BIC/AIC) for both A and B
        % BIC
        [imp_IC_AB_temp(:,1), ~, ~, lag_length] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,2000,0,0,0,0,1); % A and B via the BIC
        IC_ABA_temp(1) = lag_length.J;
        IC_ABB_temp(1) = lag_length.I;
        
        % AIC
        [imp_IC_AB_temp(:,2), ~, ~, lag_length] = ir_ADL_IC(y,x,0:1:B_max,0:1:A_max,0,L_fig,0.95,2000,0,2,0,0,1); % A and B via the AIC
        IC_ABA_temp(2) = lag_length.J;
        IC_ABB_temp(2) = lag_length.I;
        
        % 3) Information criterion for A while B = 2
        % BIC
        [imp_IC_A_temp(:,1), ~, ~, lag_length] = ir_ADL_IC(y,x,2,0:1:A_max,0,L_fig,0.95,2000,0,0,0,0,1); % A via the BIC
        IC_A_temp(1) = lag_length.J;
        
        % AIC
        [imp_IC_A_temp(:,2), ~, ~, lag_length] = ir_ADL_IC(y,x,2,0:1:A_max,0,L_fig,0.95,2000,0,2,0,0,1); % A via the AIC
        IC_A_temp(2) = lag_length.J;
        
        % 4) Information criterion for B while A = 16
        % BIC
        [imp_IC_B_temp(:,1), ~, ~, lag_length] = ir_ADL_IC(y,x,0:1:B_max,16,0,L_fig,0.95,2000,0,0,0,0,1); % B via the BIC
        IC_B_temp(1) = lag_length.I;
        
        % AIC
        [imp_IC_B_temp(:,2), ~, ~, lag_length] = ir_ADL_IC(y,x,0:1:B_max,16,0,L_fig,0.95,2000,0,2,0,0,1); % B via the AIC
        IC_B_temp(2) = lag_length.I;
        
        
        % saving the results
        imp_AB(idxn, :, :, :) = imp_AB_temp;
        imp_IC_AB(idxn, :, :) = imp_IC_AB_temp;
        imp_IC_A(idxn, :, :)  = imp_IC_A_temp;
        imp_IC_B(idxn, :, :)  = imp_IC_B_temp;
        
        IC_ABA(idxn, :) = IC_ABA_temp;
        IC_ABB(idxn, :) = IC_ABB_temp;
        IC_A(idxn, :)   = IC_A_temp;
        IC_B(idxn, :)   = IC_B_temp;
    end
    toc
    
    
    
    %% #3. Analysis
    
    % true
    psix         = populationIRF(dgpidx,16);
    
    % mean and rmse
    Eimp_AB      = mean(imp_AB);    % ir -, horizon, A-idx, B-idx
    Eimp_IC_AB   = mean(imp_IC_AB); % ir -, horizon, A and B are jointly chosen by IC (BIC, AIC)
    Eimp_IC_A    = mean(imp_IC_A);  % ir -, horizon, A is chosen by IC (BIC, AIC) given B = 2 (true unless dgp = Smets and Wouters)
    Eimp_IC_B    = mean(imp_IC_B);  % ir -, horizon, B is chosen by IC (BIC, AIC) given A = 16
    
    MSE_imp_AB   = mean( (imp_AB - repmat(psix', [N_rep, 1, A_max+1, B_max+1])).^2 );
    RMSE_imp_AB  = sqrt( MSE_imp_AB );
    RMSE_imp_IC_AB  = sqrt( mean( (imp_IC_AB - repmat(psix', [N_rep, 1, 2])).^2 ));
    RMSE_imp_IC_A   = sqrt( mean( (imp_IC_A  - repmat(psix', [N_rep, 1, 2])).^2 ));
    RMSE_imp_IC_B   = sqrt( mean( (imp_IC_B  - repmat(psix', [N_rep, 1, 2])).^2 ));
    
    % Information criterion, A and B
    EIC_ABA       = mean(IC_ABA);  % selected A by IC: -, BIC/AIC, when both A and B are chosen by IC
    EIC_ABB       = mean(IC_ABB);  % selected B by IC: -, BIC/AIC, when both A and B are chosen by IC
    EIC_A         = mean(IC_A);    % selected A by IC: -, BIC/AIC, when only A is chosen by IC given B = 2
    EIC_B         = mean(IC_B);    % selected B by IC: -, BIC/AIC, when only B is chosen by IC given A = 16
    
    % root mean integrated squared error
    RMISE_imp_AB     = squeeze(sqrt( sum( mean( (imp_AB - repmat(psix', [N_rep, 1, A_max+1, B_max+1])).^2 ), 2) / (L_fig + 1) ));
    RMISE_imp_IC_AB  = squeeze(sqrt( sum( mean( (imp_IC_AB - repmat(psix', [N_rep, 1, 2])).^2 ), 2) / (L_fig + 1) ));
    RMISE_imp_IC_A   = squeeze(sqrt( sum( mean( (imp_IC_A  - repmat(psix', [N_rep, 1, 2])).^2 ), 2) / (L_fig + 1) ));
    RMISE_imp_IC_B   = squeeze(sqrt( sum( mean( (imp_IC_B  - repmat(psix', [N_rep, 1, 2])).^2 ), 2) / (L_fig + 1) ));
    
    % Bias
    Bias_AB     = squeeze(Eimp_AB)    - repmat(psix, [1, A_max+1, B_max+1]); % ir horizon, A-idx, B-idx
    Bias_IC_AB  = squeeze(Eimp_IC_AB) - repmat(psix, [1, 2]); % ir horizon, IC
    Bias_IC_A   = squeeze(Eimp_IC_A)  - repmat(psix, [1, 2]); % ir horizon, IC
    Bias_IC_B   = squeeze(Eimp_IC_B)  - repmat(psix, [1, 2]); % ir horizon, IC
    
    % standard deviaion
    Std_AB      = std(imp_AB);
    Std_IC_AB   = std(imp_IC_AB);
    Std_IC_A    = std(imp_IC_A);
    Std_IC_B    = std(imp_IC_B);

    %% Table
    Table = [];           % mean and rmse
    TableAddendum = [];   % (average value of) chosen A and B, RMISE
    
    hSetPlusOne = (0:4:16) + 1;
    
    % true IRF
    Table = [psix(hSetPlusOne)'];
    TableAddendum = [nan(1,3)];
    
    % (A,B) = (16,BIC)
    Table = [Table; Eimp_IC_B(1,hSetPlusOne, 1); Bias_IC_B(hSetPlusOne,1)'; Std_IC_B(1,hSetPlusOne,1); RMSE_imp_IC_B(1, hSetPlusOne, 1)];
    TableAddendum = [TableAddendum; 16, nan, RMISE_imp_IC_B(1); nan, EIC_B(1), nan];
    % (A,B) = (16,AIC)
    Table = [Table; Eimp_IC_B(1,hSetPlusOne, 2); Bias_IC_B(hSetPlusOne,2)'; Std_IC_B(1,hSetPlusOne,2); RMSE_imp_IC_B(1, hSetPlusOne, 2)];
    TableAddendum = [TableAddendum; 16, nan, RMISE_imp_IC_B(2); nan, EIC_B(2), nan];
    
    % (A,B) = (BIC,BIC)
    Table = [Table; Eimp_IC_AB(1,hSetPlusOne, 1); Bias_IC_AB(hSetPlusOne,1)'; Std_IC_AB(1,hSetPlusOne,1); RMSE_imp_IC_AB(1, hSetPlusOne, 1)];
    TableAddendum = [TableAddendum; nan, nan, RMISE_imp_IC_AB(1); EIC_ABA(1), EIC_ABB(1), nan];
    % (A,B) = (AIC,AIC)
    Table = [Table; Eimp_IC_AB(1,hSetPlusOne, 2); Bias_IC_AB(hSetPlusOne,2)'; Std_IC_AB(1,hSetPlusOne,2); RMSE_imp_IC_AB(1, hSetPlusOne, 2)];
    TableAddendum = [TableAddendum; nan, nan, RMISE_imp_IC_AB(2); EIC_ABA(2), EIC_ABB(2), nan];
    
    % (A,B) = argmin MISE
    minimum = min(RMISE_imp_AB, [], 'all');
    [Aidx, Bidx] = find(RMISE_imp_AB==minimum);
    A = Aidx-1;
    B = Bidx-1;
    Table = [Table; Eimp_AB(1,hSetPlusOne, Aidx, Bidx); Bias_AB(hSetPlusOne, Aidx, Bidx)'; Std_AB(1,hSetPlusOne, Aidx, Bidx); RMSE_imp_AB(1, hSetPlusOne, Aidx, Bidx)];
    TableAddendum = [TableAddendum; nan, nan, minimum; A, B, nan];


    % A = 16, B = 0, 2, 8, 16
    TableB = [];
    TableAddendumB = [];
    
    % % (A,B) = (16,0)
    TableB = [TableB; Eimp_AB(1,hSetPlusOne, 17, 1); RMSE_imp_AB(1, hSetPlusOne, 17,1)];
    TableAddendumB = [TableAddendumB; 16, 0; nan, RMISE_imp_AB(17,1)];
    % % (A,B) = (16,2)
    TableB = [TableB; Eimp_AB(1,hSetPlusOne, 17, 3); RMSE_imp_AB(1, hSetPlusOne, 17,3)];
    TableAddendumB = [TableAddendumB; 16, 2; nan, RMISE_imp_AB(17,3)];
    % % (A,B) = (16,8)
    TableB = [TableB; Eimp_AB(1,hSetPlusOne, 17, 9); RMSE_imp_AB(1, hSetPlusOne, 17,9)];
    TableAddendumB = [TableAddendumB; 16, 8; nan, RMISE_imp_AB(17,9)];
    % % (A,B) = (16,16)
    TableB = [TableB; Eimp_AB(1,hSetPlusOne, 17, 17); RMSE_imp_AB(1, hSetPlusOne, 17,17)];
    TableAddendumB = [TableAddendumB; 16, 16; nan, RMISE_imp_AB(17,17)];
    
    eval(['save (' char(39) 'SimulationDGP' num2str(dgpidx) char(39) ')'])
    
end

