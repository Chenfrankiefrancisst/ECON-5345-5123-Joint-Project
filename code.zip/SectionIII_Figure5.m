%% Section III. Figure 5


clear
clc
close all

%%
data_ramey_quarter


lw = 2;
fs = 20;


t0 = 100; % 1914:Q3. When WWI began.
t1 = 505; % 2015:Q4. Last sample. Results are very similar when t1 = 473 = 2007:Q4.

y = macro_quarter(t0:t1,5);   % unemployment rate
X = macro_quarter(t0:t1,2);   % military news shock of Ramey and Zubairy (2018)


%%
input = 0.1;

A = 16;
level = 1;
L_imp = 16;
alpha = 0.90;
N_B = 10000;
mindelay = 0;
IC = 0;
trend = 0;


%% Subplot 1
% Newey-West bandwidth. Follow Stock and Watson (2010)'s rule of thumb. 
figure,
[imp0, cb0, shock, lag_length, adl_coef] = ir_ADL(y,X,0,A,level,L_imp,alpha,N_B,mindelay,IC,trend);
[impBIC, cbBIC, shock, lag_length, adl_coef] = ir_ADL(y,X,0:10,A,level,L_imp,alpha,N_B,mindelay,IC,trend);

% Figure 5
subplot(1,2,1),

% For legend
xx = [0:1:L_imp, L_imp:-1:0];
yy = cbBIC' *input; % A = A1, T = 100
yy = [yy(1,:), fliplr(yy(2,:))];
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(-1, 0, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A1, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(-1, 0, 'r:','linewidth', 1), hold on, % true

% Actual figure
bands = fill(xx, yy, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(0:1:L_imp, imp0 * input, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
plot(0:1:L_imp, impBIC * input, 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(0:1:L_imp, cb0 * input, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot([0,L_imp], [0,0], 'r:', 'linewidth', 1),
xlim([0,L_imp])
set(gca, 'XTick', 0:4:16)
xlabel('Quarter', 'fontsize', 20)
ylabel('$\hat{\psi}_{x,c}$ in (p.p.)', 'interpreter', 'latex', 'fontsize', 20)
title('B = 0 vs. B = 2(BIC)', 'fontsize', 20)
set(gca, 'fontsize', 20)
legend({['B = 0'],['B = 0, 90% band'],['B = 2(BIC)'],['B = 2(BIC), 90% band']}, 'fontsize', 20, 'Location', 'Northeast')

lag_length.I

% relative gain in variability
diff(cbBIC,1,2)./diff(cb0,1,2)



%% Subplot 2

% Newey-West bandwidth. Follow Stock and Watson (2010)'s rule of thumb. 
[imp0, cb0, shock, lag_length, adl_coef] = ir_ADL(y,X,0,A,level,L_imp,alpha,N_B,mindelay,IC,trend);
[impBIC, cbBIC, shock, lag_length, adl_coef] = ir_ADL(y,X,0:10,A,level,L_imp,alpha,N_B,mindelay,IC,trend);

impSet = zeros(6, 17); % (BIC, 0, 4, 8, 12, 16) * h.
impSet(1,:) = impBIC;
impSet(2,:) = imp0;

seSet = zeros(6, 17); % (BIC, 0, 4, 8, 12, 16) * h.
seSet(1,:) = diff(cbBIC,[],2) /2 / norminv((1-alpha)/2+alpha);
seSet(2,:) = diff(cb0,[],2) /2 / norminv((1-alpha)/2+alpha);
for bIdx = 4:4:A
    [imp, cb] = ir_ADL(y,X,bIdx,A,level,L_imp,alpha,N_B,mindelay,IC,trend);
    seSet(2+bIdx/4,:) = diff(cb,[],2) /2 / norminv((1-alpha)/2+alpha);
    impSet(2+bIdx/4,:) = imp;

end

seSet = seSet * input;
impSet = impSet * input;

subplot(1,2,2)
plot(0:L_imp, seSet(1,:), 'k-', 'linewidth', lw), hold on,
plot(0:L_imp, seSet(2,:), 'b-.', 'linewidth', lw), hold on,
plot(0:L_imp, seSet(4,:), 'b:', 'linewidth', lw), hold on,
plot(0:L_imp, seSet(6,:), 'b--', 'linewidth', lw), hold on,
xlim([0,L_imp])
set(gca, 'XTick', 0:4:16)
xlabel('Quarter', 'fontsize', 20)
ylabel('$s.e.~(\hat{\psi}_{x,c})$', 'interpreter', 'latex', 'fontsize', 20)
title('B = 0, 8, and 16 vs. B = 2(BIC)', 'fontsize', 20)
set(gca, 'fontsize', 20)
legend({['B = 2(BIC)'],['B = 0'],['B = 8'],['B = 16']}, 'fontsize', 20, 'Location', 'Northeast')


% relative sizes of s.e. for different values of B
seSetRelative = seSet ./ repmat(seSet(1,:), [6,1])

% %%
% figure
% subplot(1,3,1),
% % Figure 5
% % For legend
% xx = [0:1:L_imp, L_imp:-1:0];
% yy = cbBIC' *input; % A = A1, T = 100
% yy = [yy(1,:), fliplr(yy(2,:))];
% plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=100, mean
% plot(-1, 0, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A1, T=100, mean
% bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
% set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
% plot(-1, 0, 'r:','linewidth', 1), hold on, % true
% 
% % Actual figure
% bands = fill(xx, yy, [0.7, 0.7, 0.7]);
% set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
% plot(0:1:L_imp, imp0 * input, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
% plot(0:1:L_imp, impBIC * input, 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
% plot(0:1:L_imp, cb0 * input, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot([0,L_imp], [0,0], 'r:', 'linewidth', 1),
% xlim([0,L_imp])
% set(gca, 'XTick', 0:4:16)
% xlabel('Quarter', 'fontsize', 20)
% ylabel('$\hat{\psi}_{x,c}$ in (p.p.)', 'interpreter', 'latex', 'fontsize', 20)
% title('B = 0 vs. B = 2(BIC)', 'fontsize', 20)
% set(gca, 'fontsize', 20)
% legend({['B = 0'],['B = 0, 90% band'],['B = 2(BIC)'],['B = 2(BIC), 90% band']}, 'fontsize', 20, 'Location', 'Northeast')
% 
% diff(cb0,1,2)./diff(cbBIC,1,2)
% 
% 
% 
% 
% 
% % Newey-West bandwidth. Follow Stock and Watson (2010)'s rule of thumb. 
% subplot(1,3,2),
% [imp0, cb0, shock, lag_length, adl_coef] = ir_ADL(y,X,A,A,level,L_imp,alpha,N_B,mindelay,IC,trend);
% [impBIC, cbBIC, shock, lag_length, adl_coef] = ir_ADL(y,X,0:10,A,level,L_imp,alpha,N_B,mindelay,IC,trend);
% 
% % Figure 5
% % For legend
% xx = [0:1:L_imp, L_imp:-1:0];
% yy = cbBIC' *input; % A = A1, T = 100
% yy = [yy(1,:), fliplr(yy(2,:))];
% plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A2, T=100, mean
% plot(-1, 0, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A1, T=100, mean
% bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
% set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
% plot(-1, 0, 'r:','linewidth', 1), hold on, % true
% 
% % Actual figure
% bands = fill(xx, yy, [0.7, 0.7, 0.7]);
% set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
% plot(0:1:L_imp, imp0 * input, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
% plot(0:1:L_imp, impBIC * input, 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
% plot(0:1:L_imp, cb0 * input, 'b:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
% plot([0,L_imp], [0,0], 'r:', 'linewidth', 1),
% xlim([0,L_imp])
% set(gca, 'XTick', 0:4:16)
% xlabel('Quarter', 'fontsize', 20)
% ylabel('$\hat{\psi}_{x,c}$ in (p.p.)', 'interpreter', 'latex', 'fontsize', 20)
% title('B = 16 vs. B = 2(BIC)', 'fontsize', 20)
% set(gca, 'fontsize', 20)
% legend({['B = 16'],['B = 16, 90% band'],['B = 2(BIC)'],['B = 2(BIC), 90% band']}, 'fontsize', 20, 'Location', 'Northeast')
% 
% 
% diff(cb0,1,2)./diff(cbBIC,1,2)
% 
% 
% 
% 
% subplot(1,3,3)
% %plot(0:L_imp, seSet(1,:), 'k-d', 'linewidth', lw), hold on,
% plot(0:L_imp, seSet(2,:)./seSet(1,:), 'k-', 'linewidth', lw), hold on,
% plot(0:L_imp, seSet(4,:)./seSet(1,:), 'b-.', 'linewidth', lw), hold on,
% plot(0:L_imp, seSet(6,:)./seSet(1,:), 'b--', 'linewidth', lw), hold on,
% plot(0:L_imp, ones(L_imp+1), 'r:', 'linewidth', lw)
% xlim([0,L_imp])
% ylim([0 8])
% set(gca, 'XTick', 0:4:16)
% xlabel('Quarter', 'fontsize', 20)
% ylabel('$s.e.~(\hat{\psi}_{x,c})$', 'interpreter', 'latex', 'fontsize', 20)
% title('B = 0, 8, and 16 vs. B = 2(BIC)', 'fontsize', 20)
% set(gca, 'fontsize', 20)
% legend({['B = 0'],['B = 8'],['B = 16']}, 'fontsize', 20, 'Location', 'Northeast')
