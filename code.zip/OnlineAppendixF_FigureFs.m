%% Online Appendix F. More Results from Cerra and Saxena (2008)
% We use the Panel Data Toolbox for MATLAB by
%  Alvarez, Inmaculada C., Javier Barbero, and Jose L. Zofio (2017).
%  Need to add 'PanelDataMATLAB-master' and its Subfolders to MATLAB path.
% Change "sh_idx" to change a kind of shocks.
% You need an econometric toolbox to deal with panel data in MATLAB
% Data description
% Source: Cerra and Saxena (2008)
% data: time, country index, growth rate, currency crisis, banking crisis,
% stronger executive power, civil war, twin financial crisis, twin political crisis
% ctry:
% ctry.name = country code. For example, if country index in data is i,
% then the corresponding country is the ith country in ctry.name.
% ctry.geo_xx = geographic category
% ctry.income_xx = income level category
% Q: total number of countries in categories is 191, although the data set
% is about 192 countries. One country might be dropped....?
% Yugoslavia is NOT in any of categories.


%% Set-up
clear variables
clc
warning('off','all')

load cerra_saxena.mat

addpath('PanelDataMATLAB-master\data','PanelDataMATLAB-master\examples','PanelDataMATLAB-master\examplesjss','PanelDataMATLAB-master\numericalchecks','PanelDataMATLAB-master\paneldata','PanelDataMATLAB-master\unittests','PanelDataMATLAB-master\paneldata\estimation','PanelDataMATLAB-master\paneldata\stafun','PanelDataMATLAB-master\paneldata\tests','PanelDataMATLAB-master\paneldata\util')


N_ctry = 192;
T_min = 1960;
T_max = 2001;

% index set for subset of countries
ctry.num = nan(N_ctry,12);
ctry.num(:,1) = 1:1:N_ctry;
ctry.num(1:length(ctry.geo_africa),2) = ctry.geo_africa;
ctry.num(1:length(ctry.geo_asia),3) = ctry.geo_asia;
ctry.num(1:length(ctry.geo_industrial),4) = ctry.geo_industrial;
ctry.num(1:length(ctry.geo_latin_america),5) = ctry.geo_latin_america;
ctry.num(1:length(ctry.geo_middle_east),6) = ctry.geo_middle_east;
ctry.num(1:length(ctry.geo_transition),7) = ctry.geo_transition;
ctry.num(1:length(ctry.geo_western_hem_islands),8) = ctry.geo_western_hem_islands;
ctry.num(1:length(ctry.income_high),9) = ctry.income_high;
ctry.num(1:length(ctry.income_upper_middle),10) = ctry.income_upper_middle;
ctry.num(1:length(ctry.income_lower_middle),11) = ctry.income_lower_middle;
ctry.num(1:length(ctry.income_lower_income),12) = ctry.income_lower_income;


L_y = 4; % Cerra and Saxena 4/4
L_x = 4;

% Selecting the shock
sh_idx = 6; % 1 = currency, 2= banking, 3 = stronger executive power,
% 4 = civil war, 5 = twin financial crisis, 6 = twin political crisis

vartype_idx = 1; % 0 =  Homoskedasticity, 1 = Cluster at country

% Number of draws for standard error bands
N_B = 1000;

% Plot
L_fig = 8;

ql = 0.05; % 0.16 / 0.84 = 1 sd, 0.05 / 0.95 = 90%
qu = 0.95;

titlename = {'Full sample', 'Africa', 'Asia', 'Industrial countries', 'Latin America', 'Middle East', 'Transition countries', 'Western Hem. islands', 'High income', 'Upper middle income', 'Lower middle income', 'Lower income'};


%% Constructing X and y
id = data(:,2);
year = data(:,1);

y = data(:,3);

shock = data(:,sh_idx+3);

% Constructing explanatory variables
X_exo = [];
X_endo = [];
for idx1 = 1:N_ctry
    X_exo = [X_exo;lagmatrix(shock(id == idx1),0:1:L_x)];
    X_endo = [X_endo;lagmatrix(y(id == idx1),1:1:L_y)];
end
X = [X_endo, X_exo];

T_dummy = [];
for idx5 = T_min:T_max
    T_dummy = [T_dummy, year == idx5];    
end

% Eliminating NaN's
idx_nonnan = ~isnan(sum(X,2) + y);

id_nonnan = id(idx_nonnan);
year_nonnan = year(idx_nonnan);
y_nonnan = y(idx_nonnan);
X_nonnan = X(idx_nonnan,:);
T_nonnan = T_dummy(idx_nonnan,:);
imp=[];
imp_cb=[];

for idx_plot = 1:12
    %% Selecting a sub-group of countries
    idx_ctry = false(size(y_nonnan));
    for idx_4 = 1:N_ctry
        idx_ctry = idx_ctry | id_nonnan == ctry.num(idx_4,idx_plot);
    end
        
    id_fe = id_nonnan(idx_ctry);
    year_fe = year_nonnan(idx_ctry);
    y_fe = y_nonnan(idx_ctry);
    X_fe = X_nonnan(idx_ctry,:);
    T_fe = T_nonnan(idx_ctry,:);
    
    T_fe = T_fe(:,sum(T_fe) > 0);
    if ~isempty(T_fe)
        T_fe = T_fe(:,2:end);
    end
    
    %% Estimation
    ynames = {'Growth'};
    clear xnames
    if L_x <10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ')'];
        end
        for idx3 = 0:L_x
            xnames(end+1,:) = ['x(-' num2str(idx3) ')'];
        end
    elseif L_x == 10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ') '];
        end
        for idx3 = 0:L_x-1
            xnames(end+1,:) = ['x(-' num2str(idx3) ') '];
        end
        xnames(end+1,:) = ['x(-' num2str(10) ')'];
    end
    
    xnames = cellstr(xnames);
    
    if vartype_idx == 0
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe');
    else
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe', 'vartype', 'cluster', 'clusterid', id_fe);
    end
    fe.ynames = ynames;
    fe.xnames = xnames;
    
%      estdisp(fe)
    
    
    %% Converting to impulse responses and deriving standard error bands
    fe.coef = fe.coef(1:L_y + 1 + L_x);
    fe.varcoef = fe.varcoef(1:L_y+L_x+1,1:L_y+L_x+1);

    if ~isnan(sum(fe.coef));
    % impulse response
    phi = fe.coef(1:L_y);
    theta = fe.coef(L_y+1:end);
    level = 0;
    imp(:,idx_plot) = [0;adltoma(phi,theta,L_fig,level)];
    
    % Confidence bands
    imp_temp = zeros(1+1+L_fig,N_B);
    for b = 1:N_B
        [~,chk] = cholcov(fe.varcoef);
        if chk ~= 0
            fe.varcoef = (fe.varcoef + fe.varcoef')/2;
            [VM,DM] = eig(fe.varcoef);
            DM = max(DM,0);
            fe.varcoef = VM * DM / VM;
        end
        
        beta_temp = mvnrnd(fe.coef, fe.varcoef)';
        phi_temp = beta_temp(1:L_y);
        theta_temp = beta_temp(L_y+1:end);
        imp_temp(:,b) = [0;adltoma(phi_temp,theta_temp,L_fig,level)];
    end
    
    imp_cb(:,:,idx_plot) = quantile(imp_temp, [ql, qu], 2);
    
    end
end



%%

L_y = 1; % Cerra and Saxena 4/4
L_x = 8;


vartype_idx = 0; % 0 =  Homoskedasticity, 1 = Cluster at country

% Number of draws for standard error bands
N_B = 1000;

% Plot
L_fig = 8;

ql = 0.05; % 0.16 / 0.84 = 1 sd, 0.05 / 0.95 = 90%
qu = 0.95;

titlename = {'Full sample', 'Africa', 'Asia', 'Industrial countries', 'Latin America', 'Middle East', 'Transition countries', 'Western Hem. islands', 'High income', 'Upper middle income', 'Lower middle income', 'Lower income'};


%% Constructing X and y
id = data(:,2);
year = data(:,1);

y = data(:,3);

shock = data(:,sh_idx+3);
imp2=[];
imp2_cb=[];

% Constructing explanatory variables
X_exo = [];
X_endo = [];
for idx1 = 1:N_ctry
    X_exo = [X_exo;lagmatrix(shock(id == idx1),0:1:L_x)];
    X_endo = [X_endo;lagmatrix(y(id == idx1),1:1:L_y)];
end
X = [X_endo, X_exo];

T_dummy = [];
for idx5 = T_min:T_max
    T_dummy = [T_dummy, year == idx5];    
end

% Eliminating NaN's
idx_nonnan = ~isnan(sum(X,2) + y);

id_nonnan = id(idx_nonnan);
year_nonnan = year(idx_nonnan);
y_nonnan = y(idx_nonnan);
X_nonnan = X(idx_nonnan,:);
T_nonnan = T_dummy(idx_nonnan,:);

for idx_plot = 1:12
    %% Selecting a sub-group of countries
    idx_ctry = false(size(y_nonnan));
    for idx_4 = 1:N_ctry
        idx_ctry = idx_ctry | id_nonnan == ctry.num(idx_4,idx_plot);
    end
        
    id_fe = id_nonnan(idx_ctry);
    year_fe = year_nonnan(idx_ctry);
    y_fe = y_nonnan(idx_ctry);
    X_fe = X_nonnan(idx_ctry,:);
    T_fe = T_nonnan(idx_ctry,:);
    
    T_fe = T_fe(:,sum(T_fe) > 0);
    if ~isempty(T_fe)
        T_fe = T_fe(:,2:end);
    end
    
    %% Estimation
    ynames = {'Growth'};
    clear xnames
    if L_x <10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ')'];
        end
        for idx3 = 0:L_x
            xnames(end+1,:) = ['x(-' num2str(idx3) ')'];
        end
    elseif L_x == 10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ') '];
        end
        for idx3 = 0:L_x-1
            xnames(end+1,:) = ['x(-' num2str(idx3) ') '];
        end
        xnames(end+1,:) = ['x(-' num2str(10) ')'];
    end
    
    xnames = cellstr(xnames);
    
    if vartype_idx == 0
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe');
    else
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe', 'vartype', 'cluster', 'clusterid', id_fe);
    end
    fe.ynames = ynames;
    fe.xnames = xnames;
    
%      estdisp(fe)
    
    
    %% Converting to impulse responses and deriving standard error bands
    fe.coef = fe.coef(1:L_y + 1 + L_x);
    fe.varcoef = fe.varcoef(1:L_y+L_x+1,1:L_y+L_x+1);

    if ~isnan(sum(fe.coef));
    % impulse response
    phi = fe.coef(1:L_y);
    theta = fe.coef(L_y+1:end);
    level = 0;
    imp2(:,idx_plot) = [0;adltoma(phi,theta,L_fig,level)];
    
    % Confidence bands
    imp_temp = zeros(1+1+L_fig,N_B);
    for b = 1:N_B
        [~,chk] = cholcov(fe.varcoef);
        if chk ~= 0
            fe.varcoef = (fe.varcoef + fe.varcoef')/2;
            [VM,DM] = eig(fe.varcoef);
            DM = max(DM,0);
            fe.varcoef = VM * DM / VM;
        end
        
        beta_temp = mvnrnd(fe.coef, fe.varcoef)';
        phi_temp = beta_temp(1:L_y);
        theta_temp = beta_temp(L_y+1:end);
        imp_temp(:,b) = [0;adltoma(phi_temp,theta_temp,L_fig,level)];
    end
    
    imp2_cb(:,:,idx_plot) = quantile(imp_temp, [ql, qu], 2);
    
    

    end
end


%%

for idx_plot = 1:12

     idx_ctry = false(size(y_nonnan));
    for idx_4 = 1:N_ctry
        idx_ctry = idx_ctry | id_nonnan == ctry.num(idx_4,idx_plot);
    end
        
    id_fe = id_nonnan(idx_ctry);
    year_fe = year_nonnan(idx_ctry);
    y_fe = y_nonnan(idx_ctry);
    X_fe = X_nonnan(idx_ctry,:);
    T_fe = T_nonnan(idx_ctry,:);
    
    T_fe = T_fe(:,sum(T_fe) > 0);
    if ~isempty(T_fe)
        T_fe = T_fe(:,2:end);
    end
    
    
    %% Estimation
    ynames = {'Growth'};
    clear xnames
    if L_x <10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ')'];
        end
        for idx3 = 0:L_x
            xnames(end+1,:) = ['x(-' num2str(idx3) ')'];
        end
    elseif L_x == 10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ') '];
        end
        for idx3 = 0:L_x-1
            xnames(end+1,:) = ['x(-' num2str(idx3) ') '];
        end
        xnames(end+1,:) = ['x(-' num2str(10) ')'];
    end
    
    xnames = cellstr(xnames);
    
    if vartype_idx == 0
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe');
    else
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe', 'vartype', 'cluster', 'clusterid', id_fe);
    end
    fe.ynames = ynames;
    fe.xnames = xnames;
    
    fe.coef = fe.coef(1:L_y + 1 + L_x);
    fe.varcoef = fe.varcoef(1:L_y+L_x+1,1:L_y+L_x+1);

    if ~isnan(sum(fe.coef));
        
    subplot(3,4,idx_plot)
    xx = [-1:1:L_fig, L_fig:-1:-1];
    yy = imp2_cb(:,:,idx_plot)'; 
    yy = [yy(1,:), fliplr(yy(2,:))];
    % For Legend
    plot(-1, 0, 'k-', 'linewidth', 2), hold on,      
    plot(-1, 0, 'k:', 'linewidth', 1), hold on,    
    plot(-1, 0, 'b-.', 'linewidth', 2), hold on,     
    bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
    set(bands,'EdgeColor','None'), hold on,
    plot(-1, 0, 'rd-', 'linewidth', 2), hold on, % true
    
    % Actual figure
    bands = fill(xx, yy, [0.7, 0.7, 0.7]);
    set(bands,'EdgeColor','None'), hold on, % J=J1, T=100, bands
    plot(-1:1:L_fig, imp(:,idx_plot), 'k-', 'linewidth', 2), hold on,
    plot(-1:1:L_fig, imp2(:,idx_plot), 'b-.', 'linewidth', 2), hold on,      
    plot(-1:1:L_fig, imp_cb(:,:,idx_plot), 'k:', 'linewidth', 1), hold on,
    plot([-1, L_fig], [0,0], 'r-', 'linewidth', 1),
    xlim([-1,L_fig]),
    set(gca, 'fontsize', 15)
    title(titlename(idx_plot), 'fontsize', 15),
    ylabel(['N = ' num2str(fe.N)], 'fontsize', 15)

    end
end