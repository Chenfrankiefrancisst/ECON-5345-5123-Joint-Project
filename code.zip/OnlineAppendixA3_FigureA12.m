%% Online Appendix A3. Consistency of the IRF estimator for c<=A: Other Specifications

clear
clc
close all
warning('off','all')

%% #1. Set-up

% figure
lw = 2;     % line width
fs = 20;    % font size

% about simulation
N_rep    = 5000; % Monte Carlo simulation size
L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
B_max    = 4;    % I can be between 0 and I_max
A        = 16;

% matlabpool
N_B = 1;
% about DGP
T = [100, 500];        % Sample size
Tmax = max(T);
T_burnin = 500; % Burn in periods

% contemporaneous response.
L_MA = 100;     % psix(L) ~ MA(L_MA)

% Initialize
impUR1 = zeros(N_rep, L_fig+1, 2, 2);
% Unit root with linear deterministic trend: replication, forecasting horizon, 1 = dy w/ constant, 2 = y with linear trend, T-idx
impUR2 = zeros(N_rep, L_fig+1, 2, 2);
% Unit root with constant deterministic trend: replication, forecasting horizon, 1 = dy w/ constant, 2 = y with constant trend, T-idx
impTS1 = zeros(N_rep, L_fig+1, 2, 2);
% Trend stationary with a linear deterministic trend: replication, forecasting horizon, 1 = dy w/ constant, 2 = y with linear trend, T-idx
impTS2 = zeros(N_rep, L_fig+1, 2, 2);
% Stationary with a constant trend: replication, forecasting horizon, 1 = dy w/ constant, 2 = y with constant trend, T-idx


%% #2. DGP
% psi_(x): Impulse Responses
x=0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%

% The following matrix would be useful when we simulate a MA(L_MA) process.
psixt = [fliplr(psix), zeros(1, T(2) - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T(2) + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

% p and a parametrization; I drop the xi comonent to make it AR(2). This
% implies that the 'true' B = 2.
rhop1     = 0.26;
rhop2     = 0.4;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;
trueB = 2;

%% #3. Simulation
parfor idxn = 1:N_rep
    
    disp(num2str(idxn))
    
    % #3.1. Data generation
    wn = normrnd(0,1,Tmax + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:Tmax+L_MA,1);
    
    ppart = zeros(Tmax + T_burnin + 1, 1);
    apart = zeros(Tmax + T_burnin + 1, 1);
    for idx_dgp = 3:Tmax + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    xpart = xpart(1:Tmax);
    apart = apart(end-Tmax+1:end);
    
    
    ppartTS2 = ppart(end-Tmax+1:end);
    ppartTS1 = ppart + (0:1:Tmax+T_burnin)'*gy;
    ppartTS1 = ppartTS1(end-Tmax+1:end);
    
    ppartUR2 = cumsum(ppart);
    ppartUR2 = ppartUR2(end-Tmax+1:end);
    ppartUR1 = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
    ppartUR1 = ppartUR1(end-Tmax+1:end);
    
    % simulated y's
    yUR1 = xpart + ppartUR1 + apart;
    yUR2 = xpart + ppartUR2 + apart;
    yTS1 = xpart + ppartTS1 + apart;
    yTS2 = xpart + ppartTS2 + apart;
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
    
    xdy = x(2:end);  % x for dy
    dyUR1 = diff(yUR1);
    dyUR2 = diff(yUR2);
    dyTS1 = diff(yTS1);
    dyTS2 = diff(yTS2);
    
    % temporary
    impUR1_temp = zeros(L_fig+1, 2, 2);
    impUR2_temp = zeros(L_fig+1, 2, 2);
    impTS1_temp = zeros(L_fig+1, 2, 2);
    impTS2_temp = zeros(L_fig+1, 2, 2);
    
    
    % #3.2 T = 500 case
    % impUR1
    impUR1_temp(:,1,2) = ir_ADL(dyUR1,xdy,0:B_max,A,0,L_fig,0.95,N_B,0,0,0);
    impUR1_temp(:,2,2) = ir_ADL(yUR1, x,  0:B_max,A,1,L_fig,0.95,N_B,0,0,0);
    
    % impUR2
    impUR2_temp(:,1,2) = ir_ADL(dyUR2,xdy,0:B_max,A,0,L_fig,0.95,N_B,0,0,0);
    impUR2_temp(:,2,2) = ir_ADL(yUR2, x,  0:B_max,A,1,L_fig,0.95,N_B,0,0,1);
    
    % impTS1
    impTS1_temp(:,1,2) = ir_ADL(dyTS1,xdy,0:B_max,A,0,L_fig,0.95,N_B,0,0,0);
    impTS1_temp(:,2,2) = ir_ADL(yTS1, x,  0:B_max,A,1,L_fig,0.95,N_B,0,0,0);
    
    % impTS2
    impTS2_temp(:,1,2) = ir_ADL(dyTS2,xdy,0:B_max,A,0,L_fig,0.95,N_B,0,0,0);
    impTS2_temp(:,2,2) = ir_ADL(yTS2, x,  0:B_max,A,1,L_fig,0.95,N_B,0,0,1);
    
    
    % #3.3 T = 100 case
    yUR1 = yUR1(1:100);
    yUR2 = yUR2(1:100);
    yTS1 = yTS1(1:100);
    yTS2 = yTS2(1:100);
    x    = x(1:100);
    
    xdy = x(2:end);  % x for dy
    dyUR1 = diff(yUR1);
    dyUR2 = diff(yUR2);
    dyTS1 = diff(yTS1);
    dyTS2 = diff(yTS2);
    
    % impUR1
    impUR1_temp(:,1,1) = ir_ADL(dyUR1,xdy,0:B_max,A,0,L_fig,0.90,N_B,0,0,0);
    impUR1_temp(:,2,1) = ir_ADL(yUR1, x,  0:B_max,A,1,L_fig,0.90,N_B,0,0,0);
    
    % impUR2
    impUR2_temp(:,1,1) = ir_ADL(dyUR2,xdy,0:B_max,A,0,L_fig,0.90,N_B,0,0,0);
    impUR2_temp(:,2,1) = ir_ADL(yUR2, x,  0:B_max,A,1,L_fig,0.90,N_B,0,0,1);
    
    % impTS1
    impTS1_temp(:,1,1) = ir_ADL(dyTS1,xdy,0:B_max,A,0,L_fig,0.90,N_B,0,0,0);
    impTS1_temp(:,2,1) = ir_ADL(yTS1, x,  0:B_max,A,1,L_fig,0.90,N_B,0,0,0);
    
    % impTS2
    impTS2_temp(:,1,1) = ir_ADL(dyTS2,xdy,0:B_max,A,0,L_fig,0.90,N_B,0,0,0);
    impTS2_temp(:,2,1) = ir_ADL(yTS2, x,  0:B_max,A,1,L_fig,0.90,N_B,0,0,1);
    
    % #3.4 assigning the results
    impUR1(idxn,:,:,:) = impUR1_temp;
    impUR2(idxn,:,:,:) = impUR2_temp;
    impTS1(idxn,:,:,:) = impTS1_temp;
    impTS2(idxn,:,:,:) = impTS2_temp;
end



%% #4. Analyzing the results
psixJ = psix(1:L_fig+1);

% Mean
impUR1_m = squeeze(mean(impUR1,1));
impUR2_m = squeeze(mean(impUR2,1));
impTS1_m = squeeze(mean(impTS1,1));
impTS2_m = squeeze(mean(impTS2,1));

% Quantile
impUR1_q = squeeze(quantile(impUR1, [0.05, 0.95], 1));
impUR2_q = squeeze(quantile(impUR2, [0.05, 0.95], 1));
impTS1_q = squeeze(quantile(impTS1, [0.05, 0.95], 1));
impTS2_q = squeeze(quantile(impTS2, [0.05, 0.95], 1));


%% #5. PLOT
% Figure A1
% T = 100
figure,
subplot(2,2,1)
twoplot(0:L_fig, impUR1_m(:,1,1), impUR1_q(:,:,1,1), impUR1_m(:,2,1), impUR1_q(:,:,2,1), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Integrated, T = 100', 'fontsize', fs)

subplot(2,2,2)
twoplot(0:L_fig, impUR2_m(:,1,1), impUR2_q(:,:,1,1), impUR2_m(:,2,1), impUR2_q(:,:,2,1), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Integrated with a constant drift, T = 100', 'fontsize', fs)

subplot(2,2,3)
twoplot(0:L_fig, impTS1_m(:,1,1), impTS1_q(:,:,1,1), impTS1_m(:,2,1), impTS1_q(:,:,2,1), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Stationary, T = 100', 'fontsize', fs)

subplot(2,2,4)
twoplot(0:L_fig, impTS2_m(:,1,1), impTS2_q(:,:,1,1), impTS2_m(:,2,1), impTS2_q(:,:,2,1), lw)
lgd = legend('dy', 'dy, 90% band', 'y', 'y, 90% band','location','best', 'orientation', 'horizontal');
set(lgd, 'fontsize', fs)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
lgd.String{1,5} = 'True';
set(gca, 'fontsize', fs)
title('Trend stationary, T = 100', 'fontsize', fs)

% Figure A2
% T = 500
figure,
subplot(2,2,1)
twoplot(0:L_fig, impUR1_m(:,1,2), impUR1_q(:,:,1,2), impUR1_m(:,2,2), impUR1_q(:,:,2,2), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Integrated, T = 500', 'fontsize', fs)

subplot(2,2,2)
twoplot(0:L_fig, impUR2_m(:,1,2), impUR2_q(:,:,1,2), impUR2_m(:,2,2), impUR2_q(:,:,2,2), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Integrated with a constant drift, T = 500', 'fontsize', fs)

subplot(2,2,3)
twoplot(0:L_fig, impTS1_m(:,1,2), impTS1_q(:,:,1,2), impTS1_m(:,2,2), impTS1_q(:,:,2,2), lw)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
set(gca, 'fontsize', fs)
title('Stationary, T = 500', 'fontsize', fs)

subplot(2,2,4)
twoplot(0:L_fig, impTS2_m(:,1,2), impTS2_q(:,:,1,2), impTS2_m(:,2,2), impTS2_q(:,:,2,2), lw)
lgd = legend('dy', 'dy, 90% band', 'y', 'y, 90% band','location','best', 'orientation', 'horizontal');
set(lgd, 'fontsize', fs)
plot(0:L_fig, psix(1:L_fig+1), 'r-d', 'linewidth', lw)
lgd.String{1,5} = 'True';
set(gca, 'fontsize', fs)
title('Trend stationary, T = 500', 'fontsize', fs)



