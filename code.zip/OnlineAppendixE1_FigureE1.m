%% Online Appendix E1. Peak effects of monetary policy shocks
clear variables
clc
close all
warning('off','all')

% Set Variables
L_fig = 48; % Impulse-Response Horizons
N_B   = 2000; % Number of simulation for confidence bands

%% E1.i) Romer and Romer (2004) Replication
% Romer and Romer(2004) with Monthly Data
% Import data
RRmonth;
[T, ~] = size(data);
L_dy_RR = 24;
L_x_RR  = 36;

% Define variables
initdate=49-36; %49=1970:1
mp = data(initdate:end,1);
dy = data(initdate:end,2);
month = data(initdate:end,6);
y = data(initdate:end,7);
ysa = data(initdate-1:end,9); % Seasonally-adjusted IP (via Eviews)
dysa = diff(ysa); % Delta y(SA)
dummy_outlier=zeros(T,1);
dummy_outlier(172,1)=1; %172=1980:4
dummy_outlier=dummy_outlier(initdate:end);
interaction_outlier=mp.*dummy_outlier;

dummy_outlier_RR0 = lagmatrix(dummy_outlier, 0:1:L_x_RR);
dummy_outlier_RR1 = lagmatrix(dummy_outlier, 1:1:L_x_RR);
dummy_outlier_ours = lagmatrix(dummy_outlier, 0:1:L_fig);
interactionmat_outlier_RR0=lagmatrix(interaction_outlier,0:1:L_x_RR);
interactionmat_outlier_RR1=lagmatrix(interaction_outlier,1:1:L_x_RR);
interactionmat_outlier_ours=lagmatrix(interaction_outlier, 0:1:L_fig);

Month = dummyvar(month);
dummy_month = Month(:,2:end); % Dummy variable of months

clear data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% for Figure E1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% E1.i) Top Left Panel: Romer and Romer (2004); Replication, Solid Line
% Note that the data is already seasonally adjusted. 
[imp_1, imp_1_cb, ~, ~, ~] = ir_ADL(dysa, mp, L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 1);

% E1.i) Top Left Panel: Romer and Romer (2004) w/o 1980:4, dash-dotted line 
[imp_11, imp_11_cb, ~, ~, ~] = ir_ADL(dysa, [mp, dummy_outlier_RR1, interactionmat_outlier_RR1], L_dy_RR, L_x_RR, 0, L_fig, 0.9, N_B, 1);

% E1.ii). Top Right Panel: Our Preferred Specification, Solid Line
[imp_2, imp_2_cb, ~, laglength_ADL, ~] = ir_ADL(dysa, mp, [0:1:20], L_fig, 0, L_fig, 0.9, N_B, 0, 0);

% E1.ii). Top Right Panel: Our Preferred Specification w/o 1980:4,
% dash-dot line
[imp_22, imp_22_cb, ~, laglength_ADL2, ~] = ir_ADL(dysa, [mp, dummy_outlier_ours, interactionmat_outlier_ours], [0:1:20], L_fig, 0, L_fig, 0.9, N_B, 0, 0);

% E1.iii) Bottom Left Panel: With I=J=12
[imp_3, imp_3_cb, ~, ~, ~] = ir_ADL(dysa, mp, 12, 12, 0, L_fig, 0.9, N_B, 0);


% E1.iv) Bottom Right Panel
peak_c=[]; peak_bic=[]; peak_bic_0=[];
when_c=[]; when_bic=[]; when_bic_0=[];

for a=0:1:L_fig 
    [imp_c, ~, ~, ~] = ir_ADL_simple(dysa, mp, 24, a, 0, L_fig, 0.9, 1, 0);  
   [peak_c(a+1), when_c(a+1)] = max(-imp_c); % R&R (2004) baseline specification; Coibion (2012)'s Experiment
    for B = 0:6:30
   [imp_ours, ~, ~, ~] = ir_ADL_simple(dysa, mp, B, a, 0, L_fig, 0.9, 0, 0);  
   [peak_bic(a+1,B/6+1), when_bic(a+1, B/6+1)] = max(-imp_ours); % Our preferred Specification
    end
end

%% Figure E1
figure,
%set(gcf,'units','normalized','outerpos',[0 0 .85 1.2]);

subplot(2,2,1)
xx = [0:1:L_fig, L_fig:-1:0];
yy11 = imp_11_cb';
yy11 = [yy11(1,:), fliplr(yy11(2,:))];
% For the legend
plot(0, 0, 'k-', 'linewidth', 2), hold on, 
plot(0, 0, 'k:', 'linewidth', 1), hold on,
plot(-1, 0, 'k-.', 'linewidth', 2), hold on, 
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,  

bands = fill(xx, 100*yy11, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0:1:L_fig, 100*imp_1, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_1_cb, 'k:', 'linewidth', 1.5), hold on,
plot(0:1:L_fig, 100*imp_11, 'k-.', 'linewidth', 2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
axis([0 L_fig -8 2])
set(gca, 'XTick', 0:6:48)
set(gca, 'fontsize', 20)
% legend({'Full Sample','CI', 'w/o 1980:m4', 'CI'}, 'Fontsize', 15, 'Location','south', 'Orientation', 'horizontal')
title('R&R Replication', 'fontsize', 20)


subplot(2,2,2)
xx = [0:1:L_fig, L_fig:-1:0];
yy22 = imp_22_cb';
yy22 = [yy22(1,:), fliplr(yy22(2,:))];
% For the legend
plot(0, 0, 'k-', 'linewidth', 2), hold on, 
plot(0, 0, 'k:', 'linewidth', 1), hold on,
plot(-1, 0, 'k-.', 'linewidth', 2), hold on, 
bands = fill([0,0],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,  

bands = fill(xx, 100*yy22, [0.7, 0.7, 0.7]);
set(bands,'EdgeColor','None'), hold on,
plot(0:1:L_fig, 100*imp_2, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_2_cb, 'k:', 'linewidth', 1.5), hold on,
plot(0:1:L_fig, 100*imp_22, 'k-.', 'linewidth', 2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1), hold on,
axis([0 L_fig -8 2])
set(gca, 'XTick', 0:6:48)
set(gca, 'fontsize', 20)
legend({'Full Sample','CI', 'w/o 1980:m4', 'CI'}, 'Fontsize', 16, 'Location','southwest', 'Orientation', 'vertical')
title('Selected Model', 'fontsize', 20)


subplot(2,2,3)
plot(0:1:L_fig, 100*imp_3, 'k-', 'linewidth', 2), hold on,
plot(0:1:L_fig, 100*imp_3_cb, 'k:', 'linewidth', 1.5), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1)
axis([0 L_fig -8 2])
set(gca, 'XTick', 0:6:48)
set(gca, 'fontsize', 20)
legend({'Estimates','90% CI'}, 'Fontsize', 16, 'Location','southwest', 'Orientation', 'vertical')
title('A=B=12', 'fontsize', 20)

subplot(2,2,4)
plot(0:1:L_fig, -100.*peak_bic(:,1), 'r-d', ...
    0:1:L_fig, -100.*peak_bic(:,2), 'k:', ...
    0:1:L_fig, -100.*peak_bic(:,3), 'k-.', ...
    0:1:L_fig, -100.*peak_bic(:,4), 'k--', ...
    0:1:L_fig, -100.*peak_bic(:,5), 'b--', ...
    0:1:L_fig, -100.*peak_bic(:,6), 'b-', ...
    'linewidth', 2), hold on,
xlabel('A')
xlim([0 L_fig])
set(gca, 'XTick', 0:6:48)
legend({'B=0 (BIC)','B=6','B=12','B=18','B=24','B=30'}, 'Fontsize', 16)
set(gca,'Fontsize',20)
title('Peak Effects and A with Different Bs', 'fontsize', 20)

