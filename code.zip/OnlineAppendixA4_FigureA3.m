%% Online Appendix A4. Inconsistency of the IRF estimator for c>A: Other DGPs

clear
clc
close all
warning('off','all')
%% 1. Data generating process
% Set-up
% Initialize
Tlist = [100, 500];
Tmax = max(Tlist);
N_rep = 5000; % Replication


N_T = length(Tlist);
idxt = 1;
T_burnin = 500; % Burn in periods

for idxrep = 1:3
    
    L_dy_set = [8,8,8];
    L_x_set  = [12,12,12];
    
    rhop_set = [0.9, 0, 0];
    rhoa_set = [0, 0.9, -0.8];
    
    % Single-Equation ADL Specification lag
    L_dy_ADL = L_dy_set(idxrep);
    L_x_ADL  = L_x_set(idxrep);
    L_max_ADL = max([L_dy_ADL, L_x_ADL]);
    
    
    % psi's: DGP 1
    L_MA = 100;
    L_fig = 20;
    x = 0:1:L_MA;
    
    % impulse response
    % Theoretical IR x
    psix = chi2pdf(x, 10);
    psix = psix * 3 / max(psix);   % Maximum response = 3%
    
    % Theoretical IR p / a
    % parametrization
    rhop = rhop_set(idxrep); 
    rhoa = rhoa_set(idxrep);
    gy   = 0.5;
    sigmazeta = 0.5;
    sigmaxi   = 3;
    
    psizeta = rhop.^x;
    psizeta = cumsum(psizeta) * sigmazeta;
    
    psixi = rhoa.^x * sigmaxi;
    
    % Data generation
    psixt = [fliplr(psix), zeros(1, Tmax - 1)];  % Convolution. We need to flip the MA coefficients.
    lagpsix = lagmatrix(psixt,0:1:Tmax + L_MA - 1)';
    lagpsix(isnan(lagpsix)) = 0;
    
    % Temporary
    
    
    %% 2. Simulation
    
    ir        = zeros(N_rep,1+L_fig,2);    % 1 = (T=100), 2 = (T=500)
    
    parfor idxn = 1:N_rep
        
        disp(num2str(idxn))
        
        % Data generation
        wn = normrnd(0,1,Tmax + T_burnin + L_MA, 3);
        xpart = lagpsix * wn(1:Tmax+L_MA,1);
        
        ppart = zeros(Tmax + T_burnin + 1, 1);
        apart = zeros(Tmax + T_burnin + 1, 1);
        for idx_dgp = 2:Tmax + T_burnin + 1
            ppart(idx_dgp) = rhop * ppart(idx_dgp-1) + sigmazeta * wn(idx_dgp,2);
            apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
        end
        ppart = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
        
        xpart = xpart(1:Tmax);
        ppart = ppart(end-Tmax+1:end);
        apart = apart(end-Tmax+1:end);
        
        % Temporary
        ir1 = zeros(L_fig+1, 2);
        
        
        % T=500 case
        % Practical sample with size T
        x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
        y = xpart + ppart + apart;
        dy = diff(y);
        x = x(2:end);
        y = y(2:end);
        
        % Single-Equation ADL Model
        [ir1(:,2), ~, ~, ~] = ir_ADL_simple(dy, x, L_dy_ADL, L_x_ADL, 0, L_fig, 0.9, 1);
        
        
        % T=100 case
        x = x(1:100);
        dy = dy(1:100);
        
        % Single-Equation ADL Model
        [ir1(:,1), ~, ~, ~] = ir_ADL_simple(dy, x, L_dy_ADL, L_x_ADL, 0, L_fig, 0.9, 1);
    
        ir(idxn,:,:) = ir1;
        
    end



%% Plot, Figure A3
name_y = {'DGP1', 'DGP2', 'DGP3'};

% IR: 
ir_q     = squeeze(quantile(ir, [0.05, 0.5, 0.95], 1));
ir_m     = squeeze(mean(ir));

figure(200),
idx=1;
        
        
        subplot(3,2,2*idxrep), plot(0:1:L_fig, ir_q([1,3], :,2), 'k--','linewidth',1.5), hold on,
        subplot(3,2,2*idxrep), plot(0:1:L_fig, ir_m(:,2), 'k-','linewidth',2), hold on,
        subplot(3,2,2*idxrep), plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on, 
        set(gca,'fontsize',20)
        subplot(3,2,2*idxrep-1), plot(0:1:L_fig, ir_q([1,3], :,1), 'k--','linewidth',1.5), hold on,
        subplot(3,2,2*idxrep-1), plot(0:1:L_fig, ir_m(:,1), 'k-','linewidth',2), hold on,
        subplot(3,2,2*idxrep-1), plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
        set(gca,'fontsize',20)
        
        if idx == 1
            ylabel(name_y(idxrep), 'fontsize', 20), hold on,
        end



end
