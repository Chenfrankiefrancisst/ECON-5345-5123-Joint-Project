%% Section III. The Effects of Crisis Shocks
% We use the Driscoll & Kraay estimator to confidence intervals
% Data description
% Source: Cerra and Saxena (2008)
% data: time, country index, growth rate, currency crisis, banking crisis,
% stronger executive power, civil war, twin financial crisis, twin political crisis
% ctry:
% ctry.name = country code. For example, if country index in data is i,
% then the corresponding country is the ith country in ctry.name.
% ctry.geo_xx = geographic category
% ctry.income_xx = income level category
% Q: total number of countries in categories is 191, although the data set
% is about 192 countries. One country might be dropped....?
% Yugoslavia is NOT in any of categories.

%% Set-up
clc
clear
close all

% addpath('PanelDataMATLAB-master/data','PanelDataMATLAB-master/examples','PanelDataMATLAB-master/examplesjss','PanelDataMATLAB-master/numericalchecks','PanelDataMATLAB-master/paneldata','PanelDataMATLAB-master/unittests','PanelDataMATLAB-master/paneldata/estimation','PanelDataMATLAB-master/paneldata/stafun','PanelDataMATLAB-master/paneldata/tests','PanelDataMATLAB-master/paneldata/util')

load cerra_saxena.mat

N_ctry = 192;
T_min = 1960;
T_max = 2001;

% index set for subset of countries
ctry.num = nan(N_ctry,12);
ctry.num(:,1) = 1:1:N_ctry;
ctry.num(1:length(ctry.geo_africa),2) = ctry.geo_africa;
ctry.num(1:length(ctry.geo_asia),3) = ctry.geo_asia;
ctry.num(1:length(ctry.geo_industrial),4) = ctry.geo_industrial;
ctry.num(1:length(ctry.geo_latin_america),5) = ctry.geo_latin_america;
ctry.num(1:length(ctry.geo_middle_east),6) = ctry.geo_middle_east;
ctry.num(1:length(ctry.geo_transition),7) = ctry.geo_transition;
ctry.num(1:length(ctry.geo_western_hem_islands),8) = ctry.geo_western_hem_islands;
ctry.num(1:length(ctry.income_high),9) = ctry.income_high;
ctry.num(1:length(ctry.income_upper_middle),10) = ctry.income_upper_middle;
ctry.num(1:length(ctry.income_lower_middle),11) = ctry.income_lower_middle;
ctry.num(1:length(ctry.income_lower_income),12) = ctry.income_lower_income;

% For the purpose of comparison
L_y_CS = 4;
L_x_CS = 4;

L_y = 1; % Cerra and Saxena 4/4
L_x = 8;
% Time fixed effects are included.

L_y_max = max([L_y_CS, L_y]);
L_x_max = max([L_x_CS, L_x]);

vartype_idx = 2; % 0 =  Homoskedasticity, 1 = Cluster at country, 2 = Driscoll & Kraay

% Number of draws for standard error bands
N_B = 2000;

% Plot
L_fig = 8;

ql = 0.05; % 0.16 / 0.84 = 1 sd, 0.05 / 0.95 = 90%
qu = 0.95;

titlename = {'Twin financial crises. (A, B) = (4,4)', 'Twin financial crises. (A, B) = (8,1)', 'Twin political crises. (A, B) = (4,4)', 'Twin political crises. (A, B) = (8,1)'};


%% Constructing X and y
id = data(:,2);
year = data(:,1);

y = data(:,3);

figure,
%set(gcf,'units','normalized','outerpos',[0 0 .85 1.2]);


for idx_plot = 1:4
    % 1 = twin financial crises, CS, 2 = twin financial crises,
    % 3 = twin political crises, CS, 4 = twin political crises,    
    % Selecting the shock
    if idx_plot <3
        sh_idx = 5; % 1 = currency, 2= banking, 3 = stronger executive power,
        % 4 = civil war, 5 = twin financial crisis, 6 = twin political crisis
    else
        sh_idx = 6;
    end
    shock = data(:,sh_idx+3);
    
    % Constructing explanatory variables
    X_exo = [];
    X_endo = [];
    for idx1 = 1:N_ctry
        X_exo = [X_exo;lagmatrix(shock(id == idx1),0:1:L_x_max)];
        X_endo = [X_endo;lagmatrix(y(id == idx1),1:1:L_y_max)];
    end
    X = [X_endo, X_exo];

    T_dummy = [];
    for idx5 = T_min:T_max
        T_dummy = [T_dummy, year == idx5];
    end
    
    % Eliminating NaN's
    idx_nonnan = ~isnan(sum(X,2) + y);
    
    id_nonnan = id(idx_nonnan);
    year_nonnan = year(idx_nonnan);
    y_nonnan = y(idx_nonnan);
    X_nonnan = X(idx_nonnan,:);
    T_nonnan = T_dummy(idx_nonnan,:);

    %% Selecting all countries, not a sub-group of countries
    idx_ctry = false(size(y_nonnan));
    for idx_4 = 1:N_ctry
        idx_ctry = idx_ctry | id_nonnan == ctry.num(idx_4,1); % when this index is (idx_4, n), then a corresponding subgroup n is selected.
    end
    
    id_fe = id_nonnan(idx_ctry);
    year_fe = year_nonnan(idx_ctry);
    y_fe = y_nonnan(idx_ctry);
    X_fe = X_nonnan(idx_ctry,:);
    T_fe = T_nonnan(idx_ctry,:);
    
    T_fe = T_fe(:,sum(T_fe) > 0);
    if ~isempty(T_fe)
        T_fe = T_fe(:,2:end);
    end
    
    %% Estimation
    ynames = {'Growth'};
    clear xnames
    if L_x <10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ')'];
        end
        for idx3 = 0:L_x
            xnames(end+1,:) = ['x(-' num2str(idx3) ')'];
        end
    elseif L_x == 10
        for idx2 = 1:L_y
            xnames(idx2,:) = ['y(-' num2str(idx2) ') '];
        end
        for idx3 = 0:L_x-1
            xnames(end+1,:) = ['x(-' num2str(idx3) ') '];
        end
        xnames(end+1,:) = ['x(-' num2str(10) ')'];
    end
    
    xnames = cellstr(xnames);
    
    if idx_plot == 1 || idx_plot == 3
        X_fe = X_fe(:,[1:L_y_CS, L_y_max+1:L_y_max+1+L_x_CS]);
    else
        X_fe = X_fe(:,[1:L_y, L_y_max+1:L_y_max+1+L_x]);
    end
    
    if vartype_idx == 0
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe');
    elseif vartype_idx == 1
        fe = panel(id_fe, year_fe, y_fe, [X_fe,T_fe], 'fe', 'vartype', 'cluster', 'clusterid', id_fe);
    else
%         fe = panel(id_fe, year_fe, y_fe, [X_fe], 'fe');

        fe_flag = 3; % 3 = both time and country fe
        L = 3;
                
        [beta, variance, residual] = regress_dk(y_fe, X_fe, id_fe, year_fe, fe_flag, L); %
        fe.coef = beta;
        fe.varcoef = variance;
    end
    fe.ynames = ynames;
    fe.xnames = xnames;
  

    %% Converting to impulse responses and deriving standard error bands
    
    if idx_plot == 1 || idx_plot == 3
        L_y_temp = L_y_CS;
        L_x_temp = L_x_CS;
    else
        L_y_temp = L_y;
        L_x_temp = L_x;
    end
    
    fe.coef = fe.coef(1:L_y_temp + 1 + L_x_temp);
    fe.varcoef = fe.varcoef(1:L_y_temp+L_x_temp+1,1:L_y_temp+L_x_temp+1);
    
    if ~isnan(sum(fe.coef))
        % impulse response
        phi = fe.coef(1:L_y_temp);
        theta = fe.coef(L_y_temp+1:end);
        level = 0;
        imp = [0;adltoma(phi,theta,L_fig,level)];
        
        % Confidence bands
        imp_temp = zeros(1+1+L_fig,N_B);
        for b = 1:N_B
            [~,chk] = cholcov(fe.varcoef);
            if chk ~= 0
                fe.varcoef = (fe.varcoef + fe.varcoef')/2;
                [VM,DM] = eig(fe.varcoef);
                DM = max(DM,0);
                fe.varcoef = VM * DM / VM;
            end
            
            beta_temp = mvnrnd(fe.coef, fe.varcoef)';
            phi_temp = beta_temp(1:L_y_temp);
            theta_temp = beta_temp(L_y_temp+1:end);
            imp_temp(:,b) = [0;adltoma(phi_temp,theta_temp,L_fig,level)];
        end
        
        imp_cb = quantile(imp_temp, [ql, qu], 2);
        idx_plot
        [std(imp_temp,[],2), 1.65*std(imp_temp,[],2),diff(imp_cb,[],2)/2]
        
        % Figure 4
        subplot(2,2,idx_plot), plot(0:1:L_fig, imp(2:end), 'k-', 'linewidth', 2), hold on,
        plot(0:1:L_fig, imp_cb(2:end,:), 'k:', 'linewidth', 2), hold on,
        plot([0, L_fig], [0,0], 'r:', 'linewidth', 1),
        xlim([0,L_fig]),
%         xlabel('Year'),
%         ylabel('$\hat{\psi}_{x,c} ~ (\%)$ ', 'Interpreter', 'latex')
        set(gca,'FontSize',20)
        title(titlename(idx_plot), 'fontsize', 20);
    end
    
    if idx_plot < 3
        ylim([-7.05,5.05])
    else
        ylim([-25,15.05])
        xlabel('Year'),

    end
    
    if idx_plot == 1 || idx_plot == 3
        ylabel('$\hat{\psi}_{x,c} ~ (\%)$ ', 'Interpreter', 'latex')
    end
    
   
end

set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0, 0.75, 1]);