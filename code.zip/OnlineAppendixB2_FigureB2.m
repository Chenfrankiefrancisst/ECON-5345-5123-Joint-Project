%% Online Appendix B2 
clear
clc
close all
warning('off','all')

%% #1. Set-up
% about simulation
N_rep    = 5000; % Monte Carlo simulation size
L_fig    = 16;   % impulse responses would be evaluated up to the L_fig horizon
B_max    = 16;   % B can be between 0 and B_max
A1       = 8;
A2       = 16;
% matlabpool
N_B = 1;
% about DGP
T = [100, 500];        % Sample size
Tmax = max(T);
T_burnin = 500; % Burn in periods

% contemporaneous response.
L_MA = 100;     % psix(L) ~ MA(L_MA)

% Initialize
imp_B = zeros(N_rep, L_fig+1, B_max + 4, 2); % replication, forecasting horizon, I-idx including 0, BIC, HQIC, AIC, T-idx
B_IC   = zeros(N_rep, 3, 2); % selected B due to IC: replication, BIC/HQIC/AIC, T-idx

%% #2. DGP
% psi_(x): Impulse Responses
x=0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%


% The following matrix would be useful when we simulate a MA(L_MA) process.
psixt = [fliplr(psix), zeros(1, T(2) - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T(2) + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;

% p and a parametrization; 
% We estimate ARIMA(2,2) model of real GDP per capita based on the data in data_ramey_quarter.m.
rhop1     = -0.0409;
rhop2     = 0.2598;
theta1    = 0.5155;
theta2    = -0.1791;
gy        = 0.5;
sigmazeta = 8;


psie = [0;sigmazeta];

for h = 2:L_fig+1
    psie(h+1) = rhop1 * psie(h) + rhop2 * psie(h-1);
end
psie = psie(2:end);
psie = cumsum(psie)';

%% #3. Simulation
parfor idxn = 1:N_rep
    disp(num2str(idxn))
    
    % #3.1. Data generation
    wn_x = normrnd(0,1,Tmax + T_burnin + L_MA, 1);
    wn_dz = normrnd(0, sigmazeta,Tmax + T_burnin + L_MA, 1);
    wn = [wn_x, wn_dz];
    xpart = lagpsix * wn(1:Tmax+L_MA,1);
    
    ppart = zeros(Tmax + T_burnin + 1, 1);

    for idx_dgp = 4:Tmax + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + wn(idx_dgp,2) + theta1*wn(idx_dgp-1,2) + theta2*wn(idx_dgp-2,2);
    end
    ppart = cumsum(ppart) + (0:1:Tmax+T_burnin)'*gy;
    
    xpart = xpart(1:Tmax);
    ppart = ppart(end-Tmax+1:end);
  
    
    % Practical sample (y,x) with size T = 500
    x = wn(end-Tmax-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart;
    x = x(2:end);
    y = diff(y);
    
    % temporary
    imp_B_temp = zeros(L_fig+1,B_max+4,2);
    B_IC_temp = zeros(3,2);

    
    % imp_B
    % Fixed I from 0 to I_max
    for Iidx = 0:1:B_max
        imp_B_temp(:,Iidx+1,2) = ir_ADL(y,x,Iidx,A2,0,L_fig,0.95,N_B,0,0); % B = fixed, A = A2
    end
    % Information criterion
    [imp_B_temp(:,B_max+2,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,0); % B = BIC, A = A2
    B_IC_temp(1,2) = llength.I;
    [imp_B_temp(:,B_max+3,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,1); % B = HQIC, A = J2
    B_IC_temp(2,2) = llength.I;
    [imp_B_temp(:,B_max+4,2),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,2); % B = AIC, A = J2
    B_IC_temp(3,2) = llength.I;

    
    % #3.3 T = 100 case
    y = y(1:99);
    x = x(1:99);
    
    % imp_B
    % Fixed I from 0 to B_max
    for Iidx = 0:1:B_max
        imp_B_temp(:,Iidx+1,1) = ir_ADL(y,x,Iidx,A2,0,L_fig,0.95,N_B,0,0); % B = fixed, A = A2
    end
    % Information criterion
    [imp_B_temp(:,B_max+2,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,0); % B = BIC, A = A2
    B_IC_temp(1,1) = llength.I;
    [imp_B_temp(:,B_max+3,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,1); % B = HQIC, A = A2
    B_IC_temp(2,1) = llength.I;
    [imp_B_temp(:,B_max+4,1),~,~,llength] = ir_ADL(y,x,0:1:B_max,A2,0,L_fig,0.95,N_B,0,2); % B = AIC, A = A2
    B_IC_temp(3,1) = llength.I;
    

    
    % #3.4 assigning the results
    imp_B(idxn,:,:,:) = imp_B_temp; % replication, forecasting horizon, B-idx including 0, BIC, HQIC, AIC, T-idx
    B_IC(idxn,:,:) = B_IC_temp;     % selected I due to IC: replication, BIC/HQIC/AIC, T-idx
    
end


%% #4. Analyzing the results
psixA = psix(1:L_fig+1);

% Mean
imp_B_m = squeeze(mean(imp_B,1));

% Quantile
imp_B_q = squeeze(quantile(imp_B, [0.05, 0.16, 0.5, 0.84, 0.95], 1));

% MSE = BIAS^2 + SD^2
dimp = imp_B - repmat(psixA, [N_rep,1,B_max+4,2]);
mse = sum(dimp.^2,1)/N_rep;
mse = squeeze((mse));
% Bias
bias2 = (imp_B_m - repmat(psixA', [1,B_max+4,2])).^2;
% SD
var   = squeeze(std(imp_B,0,1)).^2;



%% #5. PLOT
% Online Appendix Figure B2: B & MSE, Bias^2, and Variances
for lidx = 1:18
bias2(:,lidx,1) = bias2(:,lidx,1) ./ mse(:,18,1);
bias2(:,lidx,2) = bias2(:,lidx,2) ./ mse(:,18,2);
var(:,lidx,1) = var(:,lidx,1) ./ mse(:,18,1);
var(:,lidx,2) = var(:,lidx,2) ./ mse(:,18,2);
mse(:,lidx,1) = mse(:,lidx,1) ./ mse(:,18,1);
mse(:,lidx,2) = mse(:,lidx,2) ./ mse(:,18,2);
end

figure,
% T = 100
% MSE
subplot(2,3,1),
plot(0:1:L_fig, mse(:,1,1), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,5,1), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,7,1), 'k--', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,9,1), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,18,1), 'r-d', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])
title('MSE', 'fontsize', 20)
ylabel('T = 100', 'fontsize', 20)
set(gca,'fontsize',20)

% bias^2
subplot(2,3,2),
plot(0:1:L_fig, bias2(:,1,1), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,5,1), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,7,1), 'k--', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,9,1), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,18,1), 'r-d', 'linewidth', 2), hold on
% plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])
title('Squared Bias', 'fontsize', 20)
set(gca,'fontsize',20)

% variance
subplot(2,3,3),
plot(0:1:L_fig, var(:,1,1), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,5,1), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,7,1), 'k--', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,9,1), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,18,1), 'r-d', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])
set(gca,'fontsize',20)
title('Variance', 'fontsize', 20)


% T = 500
% MSE
subplot(2,3,4),
plot(0:1:L_fig, mse(:,1,2), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,5,2), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,7,2), 'k--', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,9,2), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, mse(:,18,2), 'r-d', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])
title('MSE', 'fontsize', 20)
ylabel('T = 500', 'fontsize', 20)
set(gca,'fontsize',20)

% bias^2
subplot(2,3,5),
plot(0:1:L_fig, bias2(:,1,2), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,5,2), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,7,2), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,9,2), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, bias2(:,18,2), 'r-d', 'linewidth', 2), hold on
% plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])
title('Squared Bias', 'fontsize', 20)
set(gca,'fontsize',20)

% variance
subplot(2,3,6),
plot(0:1:L_fig, var(:,1,2), 'k-', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,5,2), 'k:', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,7,2), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,9,2), 'k-.', 'linewidth', 2), hold on
plot(0:1:L_fig, var(:,18,2), 'r-d', 'linewidth', 2), hold on
plot([0,L_fig], [1,1], 'r:', 'linewidth', 1)
xlim([0 L_fig])


legend({'0','4','6','8','BIC'},'Orientation', 'horizontal', 'Location', 'southoutside', 'fontsize', 18)
set(gca,'fontsize',20)
title('Variance', 'fontsize', 20)



