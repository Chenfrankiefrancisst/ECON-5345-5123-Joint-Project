function [psix] = populationIRF(dgpidx, L_imp)
% dgpidx 1 = hump-shaped, 2 = short run, 3 = long run and true A=1, B=2, 4 = Smets and Wouters

if dgpidx ~= 4   % bivariate
    
    if dgpidx == 1 % psi_x(L) = hump-shaped
               
        % psi_(x): Impulse Responses
        x=0:1:L_imp;
        psix = chi2pdf(x, 10);
        psix = psix * 3 / max(psix);   % Maximum response = 3%
        
    elseif dgpidx == 2 % psi_x(L) = 2(1 - rhox L)^(-1)
        sigmax = 2;
        rhox = 0.95;
        psix = sigmax * rhox.^(0:L_imp);
        
    elseif dgpidx == 3 % psi_x(L) = (1-L)^(-1)(1 - rhox L)^(-1)
        rhop1     = 0.26;
        rhop2     = 0.4;
        % (1-rhop1L - rhop2L^2) = (1-l1L)(1-l2L)
        rhox = ( rhop1 + sqrt(rhop1^2 + 4 * rhop2) ) / 2;
        %         l2 = ( rhop1 - sqrt(rhop1^2 + 4 * rhop2) ) / 2;
        psix = cumsum(rhox.^(0:L_imp));
       
    end
    
else   % Smets and Wouters
    psix = MultVarPopulation( L_imp, 1, 5, [1,5,6] );
    psix = psix / sqrt([0.0576000000000000]);  % in response to a unit shock
    
end

psix = psix(:);

end

