%% Online Appendix D3. Bias correction

clear
clc
close all
warning('on','all')
% 
% profile = parcluster('local');
% profile.NumWorkers = 56;
% parpool(profile,56)

%% 1. Data generating process
Tlist = [100];
N_rep = 5000; % Replication

% matlabpool
N_T = length(Tlist);
idxt = 1;
T = Tlist(idxt);
T_burnin = 100; % Burn in periods

% VAR Lag
L_VAR  = 16;
L_VAR2 = 17; % Specification 2 and 3 needs one more lag to make the impulse response estimates consistent.
L_VAR3 = 17;

% psi's: DGP 1
L_MA = 100;
L_fig = 16;
x = 0:1:L_MA;

rhop1     = 0.26;
rhop2     = 0.4;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;

% psi_(x): Impulse Responses
x = 0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%


% The following matrix would be useful when we simulate a MA(L_MA) process.
psixt = [fliplr(psix), zeros(1, T - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;


N_B = 1000;   % Bootstrap size
N = 2;        % Number of variables


% Handling warnings
warMsg = 'Matrix is close to singular or badly scaled.';
lenWarMsg = length(warMsg);

%% 2. Simulation
% initialization
ir1        = zeros(N_rep,1+L_fig,2);    % VAR (x, dy) 1 = from x to y , 2 = from x to sum x. It should be 1 in population.
ir2        = zeros(N_rep,1+L_fig,2);    % VAR (cumx, y) 1 = from x to y , 2 = from x to sum x. It should be 1 in population.
ir3        = zeros(N_rep,1+L_fig,2);    % VAR (cumx, y) w/ linear trend. 1 = from x to y , 2 = from x to sum x. It should be 1 in population.
ir4        = zeros(N_rep, 1+L_fig);     % Single Equation

bcorrected1 = zeros(N_rep, 1+L_fig, 2);
bcorrected2 = zeros(N_rep, 1+L_fig, 2);
bcorrected3 = zeros(N_rep, 1+L_fig, 2);
ir1Bootstrap = zeros(N_rep,N_B,1+L_fig,2);
ir2Bootstrap = zeros(N_rep,N_B,1+L_fig,2);
ir3Bootstrap = zeros(N_rep,N_B,1+L_fig,2);

% % initialization
delta1 = ones(N_rep, 1);
delta2 = ones(N_rep, 1);
delta3 = ones(N_rep, 1);

warir1Flag = false(N_rep,1);
warir1BootstrapFlag = false(N_rep,N_B);
warir2Flag = false(N_rep,1);
warir2BootstrapFlag = false(N_rep,N_B);
warir3Flag = false(N_rep,1);
warir3BootstrapFlag = false(N_rep,N_B);
%%
    
tic,
parfor idxn = 1:N_rep
    
    % initialization
    ir1BootstrapTemp = zeros(N_B,1+L_fig,2);
    ir2BootstrapTemp = zeros(N_B,1+L_fig,2);
    ir3BootstrapTemp = zeros(N_B,1+L_fig,2);
    
    disp(num2str(idxn))
    
    % Data generation
    wn = normrnd(0,1,T + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:T+L_MA,1);
    
    ppart = zeros(T + T_burnin + 1, 1);
    apart = zeros(T + T_burnin + 1, 1);
    for idx_dgp = 3:T + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:T+T_burnin)'*gy;
    
    xpart = xpart(1:T);
    ppart = ppart(end-T+1:end);
    apart = apart(end-T+1:end);
    
    % Practical sample (y,x) with size T = 100
    x = wn(end-T-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
    
    cumx = cumsum(x);
    
    x = x(2:end);
    dy = diff(y);
    %     y = y(2:end);
    % When we ues either (cum x, y), we do not need to take a difference in
    % the beginning.  
       
    
    % ir1: VAR(x, dy)
    lastwarn('');
    [C, phi, omega, psi, ~, Ttemp, residual,~, bigphi] = var_estimation([x, dy], L_VAR, L_fig,0);
    if strncmpi(lastwarn,warMsg,lenWarMsg)
        warir1Flag(idxn) = true;
        lastwarn('');
    end
    
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir1Temp = [ cumsum(squeeze(psi(2,1,:))),  cumsum(squeeze(psi(1,1,:)))];
    ir1(idxn,:,:) =  ir1Temp;    
    
    
    % Bootstrap, preparation
    companion = [reshape(phi, N, N*L_VAR); eye(N*(L_VAR-1)), zeros(N*(L_VAR-1), N)];
    lag_matrix = lagmatrix([x, dy], 1:L_VAR);
    X = lag_matrix(L_VAR+1:end,:);
    
    [~, D] = eig(companion);
    modcomp = max(abs((diag(D))));
    
    if modcomp>=1
         bcorrected1(idxn, :, :) = ir1Temp;
         delta1(idxn,1) = 0;
    else
        delta1(idxn,1) = 1;
        % shuffling
        initCondIndex  = ceil(Ttemp * rand(N_B,1));
        residCondIndex = ceil(Ttemp * rand(N_B,T+T_burnin));
        
        warir1BootstrapFlagTemp = false(N_B,1);
        for idxb=1:N_B
            % Bootstrap, generate new series
            ytemp = zeros(N*L_VAR,T+T_burnin);

            % randomly shuffled initial condition
            ytemp(:,1) = X(initCondIndex(idxb),:)';

            for t=2:T+T_burnin
                u = residual(:, residCondIndex(idxb,t));
                ytemp(:,t) = [C; zeros(N*(L_VAR-1),1)] + companion*ytemp(:,t-1) + [u; zeros(N*(L_VAR-1),1)];
            end

            Ytemp=ytemp(1:N,T_burnin+2:end)'; 
            % We start from T_burnin + '2' in consideration of the
            % differencing. That is, the effective sample size above was T-1.

            lastwarn('')
            [~, ~, omegab, psib, ~, ~, ~, ~, ~] = var_estimation(Ytemp, L_VAR, L_fig,0);
            if strncmpi(lastwarn,warMsg,lenWarMsg)
                warir1BootstrapFlagTemp(idxb,1) = true;
                lastwarn('');
            end
 
            omega_rootb =  chol(omegab,'lower');
            for h = 0:L_fig
                psib(:,:,h+1) =  psib(:,:,h+1) * omega_rootb;
            end

            ir1BootstrapTemp(idxb, :, :) = [ cumsum(squeeze(psib(2,1,:))),  cumsum(squeeze(psib(1,1,:)))];
        end
         bcorrected1(idxn, :, :) = 2 * ir1Temp - squeeze(mean(ir1BootstrapTemp));
            
    end
    
    
     
    
    
     % ir2: VAR(cumx, y)
     lastwarn('');
    [C, phi, omega, psi, ~, Ttemp, residual,~, bigphi] = var_estimation([cumx, y], L_VAR2, L_fig,0);
    if strncmpi(lastwarn,warMsg,lenWarMsg)
        warir2Flag(idxn) = true;
        lastwarn('');
    end
    
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end

    ir2Temp = [ squeeze(psi(2,1,:)),  squeeze(psi(1,1,:)) ];
    ir2(idxn,:,:) =  ir2Temp;  
    
    
    % Bootstrap, preparation
    companion = [reshape(phi, N, N*L_VAR2); eye(N*(L_VAR2-1)), zeros(N*(L_VAR2-1), N)];
    lag_matrix = lagmatrix([cumx, y], 1:L_VAR2);
    X = lag_matrix(L_VAR2+1:end,:);
    
    
    [~, D] = eig(companion);
    modcomp = max(abs((diag(D))));
    
    if modcomp>=1
         bcorrected2(idxn, :, :) = ir2Temp;
         delta2(idxn,1) = 0;
    else
        delta2(idxn,1) = 1;        
        % shuffling
        initCondIndex  = ceil(Ttemp * rand(N_B,1));
        residCondIndex = ceil(Ttemp * rand(N_B,T+T_burnin));
        
        warir2BootstrapFlagTemp = false(N_B,1);
        for idxb=1:N_B
            % Bootstrap, generate new series
            ytemp = zeros(N*L_VAR2,T+T_burnin);

            % randomly shuffled initial condition
            ytemp(:,1) = X(initCondIndex(idxb),:)';

            for t=2:T+T_burnin
                u = residual(:, residCondIndex(idxb,t));
                ytemp(:,t) = [C; zeros(N*(L_VAR2-1),1)] + companion*ytemp(:,t-1) + [u; zeros(N*(L_VAR2-1),1)];
            end

            Ytemp=ytemp(1:N,T_burnin+1:end)';
            % For models based on cumx and y, the effective sample size is T.

             lastwarn('');
            [~, ~, omegab, psib, ~, ~, ~, ~, ~] = var_estimation(Ytemp, L_VAR2, L_fig, 0);
            if strncmpi(lastwarn,warMsg,lenWarMsg)
                warir2BootstrapFlagTemp(idxb,1) = true;
                lastwarn('');
            end

            omega_rootb =  chol(omegab,'lower');
            for h = 0:L_fig
                psib(:,:,h+1) =  psib(:,:,h+1) * omega_rootb;
            end

            ir2BootstrapTemp(idxb, :, :) = [ squeeze(psib(2,1,:)), squeeze(psib(1,1,:)) ];
        end

        % Bias correction
        bcorrected2(idxn, :, :) = 2 * ir2Temp - squeeze(mean(ir2BootstrapTemp));
                    
    end
    
    
    
    % ir3: VAR(cumx, y) with linear trend
     lastwarn('');
    [C, phi, omega, psi, ~, Ttemp, residual, phi_trend, bigphi] = var_estimation([cumx, y], L_VAR3, L_fig,1);
    if strncmpi(lastwarn,warMsg,lenWarMsg)
        warir3Flag(idxn) = true;
        lastwarn('');
    end
    
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir3Temp = [ squeeze(psi(2,1,:)),  squeeze(psi(1,1,:)) ];
    ir3(idxn,:,:) =  ir3Temp;  
    
    
    % Bootstrap, preparation
    companion = [reshape(phi, N, N*L_VAR3); eye(N*(L_VAR3-1)), zeros(N*(L_VAR3-1), N)];
    lag_matrix = lagmatrix([cumx, y], 1:L_VAR3);
    X = lag_matrix(L_VAR3+1:end,:);

    [~, D] = eig(companion);
    modcomp = max(abs((diag(D))));
    
    if modcomp>=1
         bcorrected3(idxn, :, :) = ir3Temp;
         delta3(idxn,1) = 0;
    else
        delta3(idxn, 1) = 1;
        % shuffling
        initCondIndex  = ceil(Ttemp * rand(N_B,1));
        residCondIndex = ceil(Ttemp * rand(N_B,T+T_burnin));
        
        warir3BootstrapFlagTemp = false(N_B,1);
        for idxb=1:N_B
            % Bootstrap, generate new series
            ytemp = zeros(N*L_VAR3,T+T_burnin);

            % randomly shuffled initial condition
            ytemp(:,1) = X(initCondIndex(idxb),:)';

            for t=2:T+T_burnin
                u = residual(:, residCondIndex(idxb,t));
                ytemp(:,t) = [C + phi_trend*t; zeros(N*(L_VAR3-1),1)] + companion*ytemp(:,t-1) + [u; zeros(N*(L_VAR3-1),1)];
            end 

            Ytemp=ytemp(1:N,T_burnin+1:end)';
            % For models based on cumx and y, the effective sample size is T.
            
             lastwarn('');
            [~, ~, omegab, psib, ~, ~, ~] = var_estimation(Ytemp, L_VAR3, L_fig, 1);
            if strncmpi(lastwarn,warMsg,lenWarMsg)
                warir3BootstrapFlagTemp(idxb,1) = true;
                lastwarn('');
            end


            omega_rootb =  chol(omegab,'lower');
            for h = 0:L_fig
                psib(:,:,h+1) =  psib(:,:,h+1) * omega_rootb;
            end

            ir3BootstrapTemp(idxb, :, :) = [ squeeze(psib(2,1,:)), squeeze(psib(1,1,:)) ];
        end

        % Bias correction
        bcorrected3(idxn, :, :) = 2 * ir3Temp - squeeze(mean(ir3BootstrapTemp));
 
    end
    
    % ir4: Single equation
    [imp, shock] = ir_ADL_simple(dy,x,0:4,16,0,16,.90,0,0);
    ir4(idxn,:) = imp * shock.std;
    
    
end


%%

% IR: summary
ir1_q     = squeeze(quantile(ir1, [0.025, 0.5, 0.975], 1));
ir2_q     = squeeze(quantile(ir2, [0.025, 0.5, 0.975], 1));
ir3_q     = squeeze(quantile(ir3, [0.025, 0.5, 0.975], 1));
ir4_q     = squeeze(quantile(ir4, [0.05, 0.5, 0.95], 1));

ir1_m     = squeeze(mean(ir1, 1));
ir2_m     = squeeze(mean(ir2, 1));
ir3_m     = squeeze(mean(ir3, 1));
ir4_m     = squeeze(mean(ir4, 1));

ir1_q_bc     = squeeze(quantile(bcorrected1, [0.025, 0.5, 0.975], 1));
ir2_q_bc     = squeeze(quantile(bcorrected2, [0.025, 0.5, 0.975], 1));
ir3_q_bc     = squeeze(quantile(bcorrected3, [0.025, 0.5, 0.975], 1));

ir1_m_bc     = squeeze(mean(bcorrected1,1));
ir2_m_bc     = squeeze(mean(bcorrected2,1));
ir3_m_bc     = squeeze(mean(bcorrected3,1));


% save Figure4Bootstrap
% save('bootstrapir.mat', 'bcorrected1', 'bcorrected2', 'bcorrected3', 'ir1', 'ir2', 'ir3', 'ir1_q', 'ir2_q', 'ir3_q', 'ir1_m', 'ir2_m', 'ir3_m', 'ir1_q_bc', 'ir2_q_bc', 'ir3_q_bc', 'ir1_m_bc', 'ir2_m_bc', 'ir3_m_bc', 'delta1', 'delta2', 'delta3')
% toc
%% 3. Figure D3, bias-corrected VAR

fs = 20;
lw = 2;

name_title = { '$(x, \Delta y)^{\prime}: ~ x \rightarrow y$', ...
    '$(x, \Delta y)^{\prime}: ~ x \rightarrow \tilde{x}$', ...
    '$(\tilde{x}, y)^{\prime}: ~ x \rightarrow y$', ...
    '$(\tilde{x}, y)^{\prime}: ~ x \rightarrow \tilde{x}$', ...
    '$(\tilde{x}, y)^{\prime} ~w/~ trend: ~ x \rightarrow y$', ...
    '$(\tilde{x}, y)^{\prime} ~w/~ trend: ~ x \rightarrow \tilde{x}$'};

figure,
%set(gcf,'units','normalized','outerpos',[0 0 .85 1.2]);

subplot(3,2,1)
twoplot(0:L_fig, ir1_m_bc(:,1), ir1_q_bc([1,3],:,1), ir1_m(:,1), ir1_q([1,3],:,1), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, psix(1, 1:L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-5 7])
set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(1), 'interpreter', 'latex', 'fontsize', fs)

subplot(3,2,2)
twoplot(0:L_fig, ir1_m_bc(:,2), ir1_q_bc([1,3],:,2), ir1_m(:,2), ir1_q([1,3],:,2), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, ones(1, L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-0.5 2])
set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(2), 'interpreter', 'latex', 'fontsize', fs)

subplot(3,2,3)
twoplot(0:L_fig, ir2_m_bc(:,1), ir2_q_bc([1,3],:,1), ir2_m(:,1), ir2_q([1,3],:,1), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, psix(1, 1:L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-5 7])
set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(3), 'interpreter', 'latex', 'fontsize', fs)

subplot(3,2,4)
twoplot(0:L_fig, ir2_m_bc(:,2), ir2_q_bc([1,3],:,2), ir2_m(:,2), ir2_q([1,3],:,2), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, ones(1, L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-0.5 2])
set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(4), 'interpreter', 'latex', 'fontsize', fs)

subplot(3,2,5)
twoplot(0:L_fig, ir3_m_bc(:,1), ir3_q_bc([1,3],:,1), ir3_m(:,1), ir3_q([1,3],:,1), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, psix(1, 1:L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-5 7])
set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(5), 'interpreter', 'latex', 'fontsize', fs)

subplot(3,2,6)
%for legend
plot(-1, 0, 'k-', 'linewidth', 2), hold on,      % A = A2, T=100, mean
plot(-1, 0, 'k:', 'linewidth', 1.5), hold on,      % A = A2, T=100, bands
plot(-1, 0, 'b-.', 'linewidth', 2), hold on,      % A = A1, T=100, mean
bands = fill([-1,-1],[0,0], [0.7,0.7,0.7]);
set(bands,'EdgeColor','None'), hold on, % A = A1, T=100, bands
plot(-1, 0, 'rd-', 'linewidth', 2), hold on, % true

%actual figure
twoplot(0:L_fig, ir3_m_bc(:,2), ir3_q_bc([1,3],:,2), ir3_m(:,2), ir3_q([1,3],:,2), lw, 1, 'b-.', 'k-', 'k:',2, 'r-d')
plot(0:L_fig, ones(1, L_fig+1), 'r-d', 'linewidth', lw), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', lw/2),
xlim([0 L_fig]), ylim([-0.5 2])
legend({'VAR, Mean', 'VAR, 90% band', 'Bias-Corrected VAR, Mean', 'Bias-Corrected VAR, 90% band', 'True'}, 'fontsize', fs, 'Orientation', 'horizontal', 'Location', 'South')

set(gca, 'XTick', 0:4:16)
set(gca, 'fontsize', fs)
title(name_title(6), 'interpreter', 'latex', 'fontsize', fs)

% 
% %% 4. MSEs
% 
% psixJ = psix(1:L_fig+1);
% dir1 = ir1;
% dir1(:,:,1) = dir1(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir1(:,:,2) = dir1(:,:,2) -1;
% mse1 = squeeze(mean(dir1.^2));
% 
% dir2 = ir2;
% dir2(:,:,1) = dir2(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir2(:,:,2) = dir2(:,:,2) -1;
% mse2 = squeeze(mean(dir2.^2));
% 
% dir3 = ir3;
% dir3(:,:,1) = dir3(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir3(:,:,2) = dir3(:,:,2) -1;
% mse3 = squeeze(mean(dir3.^2));
% 
% dir4 = ir4;
% dir4(:,:,1) = dir4(:,:,1) - repmat(psixJ, [N_rep, 1]);
% mse4 = squeeze(mean(dir4.^2))';
% 
% 
% dir1_bc = bcorrected1;
% dir1_bc(:,:,1) = dir1_bc(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir1_bc(:,:,2) = dir1_bc(:,:,2) -1;
% mse1_bc = squeeze(mean(dir1_bc.^2));
% 
% dir2_bc = bcorrected2;
% dir2_bc(:,:,1) = dir2_bc(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir2_bc(:,:,2) = dir2_bc(:,:,2) -1;
% mse2_bc = squeeze(mean(dir2_bc.^2));
% 
% dir3_bc = bcorrected3;
% dir3_bc(:,:,1) = dir3_bc(:,:,1) - repmat(psixJ, [N_rep, 1]);
% dir3_bc(:,:,2) = dir3_bc(:,:,2) -1;
% mse3_bc = squeeze(mean(dir3_bc.^2));
% 
% 
% 
% 
% disp(' MSE of SE, VAR (x,dy), VAR (sum x, y), VAR trend + (sum x, y)')
% [ mse4(9,1), mse1(9,1), mse2(9,1), mse3(9,1)]
% 
% disp(' MSE of SE, BC VAR (x,dy), BC VAR (sum x, y), BC VAR trend + (sum x, y)')
% [ mse4(9,1), mse1_bc(9,1), mse2_bc(9,1), mse3_bc(9,1)]
% 
% 
% 
% %% 5. MSE plot
% 
% name_title = { '$(x, \Delta y)^{\prime}: ~ x \rightarrow y$', ...
%     '$(x, \Delta y)^{\prime}: ~ x \rightarrow \sum x$', ...
%     '$(\sum x, y)^{\prime}: ~ x \rightarrow y$', ...
%     '$(\sum x, y)^{\prime}: ~ x \rightarrow \sum x$', ...
%     '$(\sum x, y)^{\prime} ~w/~ trend: ~ x \rightarrow y$', ...
%     '$(\sum x, y)^{\prime} ~w/~ trend: ~ x \rightarrow \sum x$'};
% 
% figure,
% 
% 
% subplot(3,2,1)
% plot(0:1:L_fig, mse1(:, 1), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse4, 'b-o','linewidth',2); hold on;
% plot(0:1:L_fig, mse1_bc(:, 1), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(1), 'interpreter', 'latex', 'fontsize', 15)
% set(gca,'fontsize',15)
% xlim([0 L_fig]),
% ylim([0 7])
% 
% subplot(3,2,2)
% plot(0:1:L_fig, mse1(:, 2), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse1_bc(:, 2), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(2), 'interpreter', 'latex', 'fontsize', 15)
% set(gca,'fontsize',15)
% xlim([0 L_fig]),
% ylim([0 0.35])
% 
% subplot(3,2,3)
% plot(0:1:L_fig, mse2(:, 1), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse4, 'b-o','linewidth',2); hold on;
% plot(0:1:L_fig, mse2_bc(:, 1), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(3), 'interpreter', 'latex', 'fontsize', 15)
% set(gca,'fontsize',15)
% xlim([0 L_fig]),
% ylim([0 7])
% 
% subplot(3,2,4)
% plot(0:1:L_fig, mse2(:, 2), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse2_bc(:, 2), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(4), 'interpreter', 'latex', 'fontsize', 15)
% set(gca,'fontsize',15)
% xlim([0 L_fig]),
% ylim([0 1])
% 
% subplot(3,2,5)
% plot(0:1:L_fig, mse3(:, 1), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse4, 'b-o','linewidth',2); hold on;
% plot(0:1:L_fig, mse3_bc(:, 1), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(5), 'interpreter', 'latex', 'fontsize', 15)
% set(gca,'fontsize',15)
% xlim([0 L_fig]),
% legend({'MSE of VAR', 'MSE of SE', 'MSE of b-corrected VAR'}, 'fontsize', 15, 'Orientation','horizontal', 'Location', 'South')
% ylim([0 7])
% 
% subplot(3,2,6)
% % for legend
% plot(0:1:L_fig, mse3(:, 2), 'k-','linewidth',2); hold on;
% plot(0:1:L_fig, mse3_bc(:, 2), 'r-d','linewidth',2), hold on,
% set(gca, 'XTick', 0:4:16)
% title(name_title(6), 'interpreter', 'latex', 'fontsize', 15)
% xlim([0 L_fig]),
% ylim([0 1])
% set(gca,'fontsize',15)
