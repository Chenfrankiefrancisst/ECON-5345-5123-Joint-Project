%% Online Appendix D2. Bivarite VAR
% Figure D1

clear
clc
close all
warning('off','all')


%% 1. Data generating process
Tlist = [100];
N_rep = 5000; % Replication

% matlabpool
N_T = length(Tlist);
idxt = 1;
T = Tlist(idxt);
T_burnin = 100; % Burn in periods

% VAR Lag
L_VAR  = 16;
L_VAR2 = 17; % Specification 2 and 3 needs one more lag to make the impulse response estimates consistent.
L_VAR3 = 17;

% psi's: DGP 1
L_MA = 100;
L_fig = 16;
x = 0:1:L_MA;

rhop1     = 0.26;
rhop2     = 0.4;
rhoa      = 0;
gy        = 0.5;
sigmazeta = 1.5;
sigmaxi   = 0;

% psi_(x): Impulse Responses
x = 0:1:L_MA;
psix = chi2pdf(x, 10);
psix = psix * 3 / max(psix);   % Maximum response = 3%


% The following matrix would be useful when we simulate a MA(L_MA) process.
psixt = [fliplr(psix), zeros(1, T - 1)];  % Convolution. We need to flip the MA coefficients.
lagpsix = lagmatrix(psixt,0:1:T + L_MA - 1)';
lagpsix(isnan(lagpsix)) = 0;


%% 2. Simulation
% initialization
ir1        = zeros(N_rep,1+L_fig,2);    % VAR (x, dy) 1 = from x to y , 2 = from x to sum x. It should be 1 in population.
ir2        = zeros(N_rep,1+L_fig,2);    % VAR (cumx, y) 1 = from x to y , 2 = from x to sum x. It should be 1 in population.
ir4        = zeros(N_rep, 1+L_fig);     % Single Equation


tic,
for idxn = 1:N_rep
    
    disp(num2str(idxn))
    
    % Data generation
    wn = normrnd(0,1,T + T_burnin + L_MA, 3);
    xpart = lagpsix * wn(1:T+L_MA,1);
    
    ppart = zeros(T + T_burnin + 1, 1);
    apart = zeros(T + T_burnin + 1, 1);
    for idx_dgp = 3:T + T_burnin + 1
        ppart(idx_dgp) = rhop1 * ppart(idx_dgp-1) + rhop2 * ppart(idx_dgp-2) + sigmazeta * wn(idx_dgp,2);
        apart(idx_dgp) = rhoa * apart(idx_dgp-1) + sigmaxi * wn(idx_dgp,3);
    end
    ppart = cumsum(ppart) + (0:1:T+T_burnin)'*gy;
    
    xpart = xpart(1:T);
    ppart = ppart(end-T+1:end);
    apart = apart(end-T+1:end);
    
    % Practical sample (y,x) with size T = 100
    x = wn(end-T-T_burnin+1:end-T_burnin,1);
    y = xpart + ppart + apart;
    
    cumx = cumsum(x);
    
    x = x(2:end);
    dy = diff(y);
    % When we ues either (cum x, y), we do not need to take a difference in
    % the beginning.
      
    
    % ir1: VAR(x, dy)
    [C, phi, omega, psi, ~, Ttemp, residual] = var_estimation([x, dy], L_VAR, L_fig,0);
 
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end
    
    ir1Temp = [ cumsum(squeeze(psi(2,1,:))),  cumsum(squeeze(psi(1,1,:)))];
    ir1(idxn,:,:) =  ir1Temp;    
    
    
   
    % ir2: VAR(cumx, y)
    [C, phi, omega, psi, ~, Ttemp, residual] = var_estimation([cumx, y], L_VAR2, L_fig,0);
    
    omega_root = chol(omega,'lower');
    
    for h = 0:L_fig
        psi(:,:,h+1) =  psi(:,:,h+1) * omega_root;
    end

    ir2Temp = [ squeeze(psi(2,1,:)),  squeeze(psi(1,1,:)) ];
    ir2(idxn,:,:) =  ir2Temp;  
    
    % ir4: Single equation
    [imp, shock] = ir_ADL_simple(dy,x,0:4,16,0,16,.90,0,0);
    ir4(idxn,:) = imp * shock.std;
       

end


% IR: summary
ir1_q     = squeeze(quantile(ir1, [0.05, 0.5, 0.95], 1));
ir2_q     = squeeze(quantile(ir2, [0.05, 0.5, 0.95], 1));
ir4_q     = squeeze(quantile(ir4, [0.05, 0.5, 0.95], 1));

ir1_m     = squeeze(mean(ir1, 1));
ir2_m     = squeeze(mean(ir2, 1));
ir4_m     = squeeze(mean(ir4))';

toc

%% 3. Figure D1 (without Bias correction)

name_title = { '$(x, \Delta y)^{\prime}: ~ x \rightarrow y$', ...
    '$(x, \Delta y)^{\prime}: ~ x \rightarrow \tilde{x}$', ...
    '$(\tilde{x}, y)^{\prime}: ~ x \rightarrow y$', ...
    '$(\tilde{x}, y)^{\prime}: ~ x \rightarrow \tilde{x}$'};

figure,
%set(gcf,'units','normalized','outerpos',[0 0 .85 1.2]);
subplot(2,2,1)
plot(0:1:L_fig, ir1_m(:, 1), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir1_q([1,3],:,1), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-3 5])
set(gca, 'XTick', 0:4:16)
title(name_title(1), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(2,2,2)
plot(0:1:L_fig, ir1_m(:, 2), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir1_q([1,3], :,2), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, ones(L_fig+1,1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-0.5 1.5])
set(gca, 'XTick', 0:4:16)
title(name_title(2), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(2,2,3)
plot(0:1:L_fig, ir2_m(:, 1), 'k-','linewidth',2); hold on;
plot(0:1:L_fig, ir2_q([1,3], :,1), 'k:', 'linewidth', 1.5); hold on;
plot(0:1:L_fig, psix(1:L_fig+1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-3 5])
set(gca, 'XTick', 0:4:16)
title(name_title(3), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)

subplot(2,2,4)
plot(0:1:L_fig, ir2_q([1,3], :, 2), 'k:','linewidth',1.5), hold on,
plot(0:1:L_fig, ir2_m(:, 2), 'k-','linewidth',2), hold on,
plot(0:1:L_fig, ones(L_fig+1,1), 'r-d','linewidth',2), hold on,
plot([0,L_fig], [0,0], 'r:', 'linewidth', 1),
xlim([0 L_fig]),
ylim([-0.5 1.5])
set(gca, 'XTick', 0:4:16)
title(name_title(4), 'interpreter', 'latex', 'fontsize', 20)
set(gca,'fontsize',20)


%% 4. MSEs

psixJ = psix(1:L_fig+1);
dir1 = ir1;
dir1(:,:,1) = dir1(:,:,1) - repmat(psixJ, [N_rep, 1]);
dir1(:,:,2) = dir1(:,:,2) -1;
mse1 = squeeze(mean(dir1.^2));

dir2 = ir2;
dir2(:,:,1) = dir2(:,:,1) - repmat(psixJ, [N_rep, 1]);
dir2(:,:,2) = dir2(:,:,2) -1;
mse2 = squeeze(mean(dir2.^2));

dir4 = ir4;
dir4(:,:,1) = dir4(:,:,1) - repmat(psixJ, [N_rep, 1]);
mse4 = squeeze(mean(dir4.^2))';

disp(' MSE of SE, VAR (x,dy), VAR (sum x, y)')
[ mse4(9,1), mse1(9,1), mse2(9,1)]

